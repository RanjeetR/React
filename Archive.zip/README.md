This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`


Component should be placed under the src/lib/component folder

example folder is used to create example of the component