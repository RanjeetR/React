
import React from 'react';
import {
  BrowserRouter as Router, Switch, Route,
} from 'react-router-dom';
import { ThemeProvider, createMuiTheme, responsiveFontSizes } from '@material-ui/core/styles';
import { IntlProvider } from 'react-intl';
import SearchnBrowse from './views/searchnbrowse/SearchnBrowse';

import HomePage from './views/homepage/HomePage';

import ProductPage from './views/productpage/product';
import CartnCheckout from './views/cartncheckout/CartnCheckout';
import getLocaleData from './localisation/localeData';
import TimePass from './TimePass';
import * as componentlocales from './localisation/componentLocalisation';


import './views/styles/GlobalStyles.scss';

// english is a fallback locale.
const locale = 'en';
const localeData = getLocaleData(locale) || 'en';


const customTheme = createMuiTheme({
  typography: {
    fontFamily: '"Maven Pro", sans-serif',
  },
}, componentlocales[locale]);

const theme = responsiveFontSizes(customTheme);

function App() {
  return (
    <>
      <IntlProvider locale={localeData.locale} messages={localeData.messages}>
        <link href="https://fonts.googleapis.com/css?family=Maven+Pro:400,500,700&display=swap" rel="stylesheet" />
        <ThemeProvider theme={theme}>
          <div className="App">
            <Router>
              <Switch>
                <Route exact path="/">
                  <HomePage />
                </Route>
                <Route path="/home">
                  <HomePage />
                </Route>
                <Route path="/search">
                  <SearchnBrowse />
                </Route>
                <Route path="/product/prd-:id">
                  <ProductPage />
                </Route>
                <Route path="/checkout">
                  <CartnCheckout />
                </Route>
                <Route path="/timepass">
                  <TimePass />
                </Route>
              </Switch>
            </Router>
          </div>
        </ThemeProvider>
      </IntlProvider>
    </>
  );
}

export default App;
