import React from 'react';

const TestComponent = ({ options }) => {
  const getItems = options.map((name, index) => (
         <li key={index}>
           {' '}
           {name}
           {' '}
         </li>
       ));

  return (
    <>
      <ul>
        {getItems}
      </ul>
    </>
  );
};

export default TestComponent;
