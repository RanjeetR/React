// define action types
export const SETPRODUCT = 'SETPRODUCT';
export const FILTER = 'FILTER';
