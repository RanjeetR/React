/* eslint-disable no-param-reassign */
import {
  SETPRODUCT, FILTER,
} from './ActionTypes';

// set initial data
export const initialState = {
  status: null,
  response: null,
};

// define SnbReducer
const ProductReducer = (state = initialState, { type, response } = {}) => {
  switch (type) {
    case SETPRODUCT:
      return { ...state, status: SETPRODUCT, response };
    case FILTER:
      state.response.product.preSelectedColor = response.activeColorOption;
      state.response.product.preSelectedSize = response.activeSizeOption;
      return { ...state, status: FILTER };
    default:
      return state;
  }
};

export default ProductReducer;
