import constant from  '../../config/env_dev.constant';
const { enableLogs } = constant;
class logger {
  static info(msg, traceObj={}) {
    const colorStr = '%c StoreFront info!';
    const colors = 'background:  #a29b9b; color: black';

    if (enableLogs) this.printMsg( colorStr, colors, msg, traceObj);
  }

  static warn(msg, traceObj={}) {
    const colorStr = '%c StoreFront warn!';
    const colors = 'background: yellow; color: orange';
    if (enableLogs) this.printMsg( colorStr, colors, msg, traceObj);
  }

  static log(msg, traceObj={}) {
    const colorStr = '%c StoreFront success!';
    const colors = 'background: #5bb55b; color: black';
    if (enableLogs) this.printMsg( colorStr, colors, msg, traceObj);
  }

  static error(msg, traceObj={}) {
    const colorStr = '%c StoreFront error!';
    const colors = 'background: red; color: black';
    if (enableLogs) this.printMsg( colorStr, colors, msg, traceObj);
  }

static printMsg(colorStr, colors, msg, object) {
      try {
        console.log(colorStr,colors,  msg, object);
      } catch {
        console.log( msg, object);
      }

  }
}
export default logger;
