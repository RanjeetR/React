/* eslint-disable no-console */
import axiosInstance from './axiosConfig';
import APP_API from './apiList';
import logger from '../logger/Logger';
/**
 * Request Wrapper for default success/error actions
 * @param {*} options
 */
const request = (options) => {
  const success = (response) => {
    logger.log('Request Successful!', response);
    return response.data;
  };

  const error = (e) => {
    logger.error('Request Failed');

    if (e.response) {
      // Request was made but server responded with something
      console.error('Status:', e.response.status);
      console.error('Data:', e.response.data);
      console.error('Headers:', e.response.headers);
    } else {
      // Something else happened while setting up the request
      // triggered the error
      logger.error('Error Message:', e.message);
    }

    return Promise.reject(e.response || e.message);
  };
  // serice call with provided options
  return axiosInstance(options)
    .then(success)
    .catch(error);
};
/**
 * Get call
 * @param {*} url
 */
const get = (url) => {
  const sericeUrl = url;
  return request({
    url: sericeUrl,
    method: 'GET',
  });
};
/**
 * Post call
 * @param {*} url , params as service payload
 */
const post = (url, params = {}) => {
  const sericeUrl = APP_API[url];
  return request({
    url: sericeUrl,
    method: 'POST',
    data: params,
  });
};

// expose methods, We can add update, delete as well
export { get, post };
