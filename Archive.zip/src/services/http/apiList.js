
const baseUrl = 'http://localhost:3000/api/';
const APP_API = {
  homepage: `${baseUrl}home_page_data.json`,
  header: `${baseUrl}header_data.json`,
  product: `${baseUrl}product_data.json`,
  search_browse: `${baseUrl}product_listing_data.json`,
  search_browse_api: `${baseUrl}products`,
  shopping_cart: `${baseUrl}card_data.json`,
  footer_data: `${baseUrl}footer.json`,
};

export default APP_API;
