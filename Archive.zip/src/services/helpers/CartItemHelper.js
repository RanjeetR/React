/* eslint-disable max-len */
import APP_API from '../http/apiList';
import { get } from '../http/request';
import logger from '../logger/Logger';
/**
 * This function will merge the local cart items to the saved cartitems from the backend
 * Local items should be discarded once checkout is done
 * @param {*} backEndShoppingCart - the data coming from services
 * TODO- make a call to server once merging is done and clear the local items
 */
const mergeCart = (backEndShoppingCart) => {
  const cartdata = localStorage.getItem('mycart');
  if (cartdata) {
    const cartdataParsed = (JSON.parse(cartdata).shoppingCart);
    const finalShoppingCart = [...cartdataParsed, ...backEndShoppingCart];
    const uniqueCartItems = Array.from(new Set(finalShoppingCart.map((a) => a.skuId)))
      .map((skuId) => finalShoppingCart.find((a) => a.skuId === skuId));
    // make REST call to save updated values in the backend
    // clear the localstorage so it will not run the iteration again.
    return uniqueCartItems;
  }

  return backEndShoppingCart;
};
/**
 * Method will resolve the updated items
 */
const getShoppingCart = () => new Promise((resolve, reject) => {
  const isLoggend = true; // need to remove with service implementation
  if (isLoggend) {
    get(APP_API.shopping_cart)
      .then((response) => {
        const mergeItems = mergeCart(response.shoppingCart || []);
        resolve(mergeItems);
      }).catch((err) => reject(err));
  } else {
    // Instead of localstorage we can use context api - TODO
    const cartdata = localStorage.getItem('mycart');
    if (cartdata) { resolve((JSON.parse(cartdata).shoppingCart)); } else {
      resolve([]);
    }
  }
});


const addItemTocart = (_productDetails) => new Promise((resolve, reject) => {
  const cartdata = localStorage.getItem('mycart');
  if (cartdata) {
    const cartDataObject = JSON.parse(cartdata);
    const foundIndex = cartDataObject.shoppingCart.findIndex((element) => element.skuId === _productDetails.skuId);
    if (foundIndex > -1) cartDataObject.shoppingCart.splice(foundIndex, 1);
    cartDataObject.shoppingCart.push(_productDetails);
    localStorage.removeItem('mycart');
    localStorage.setItem('mycart', JSON.stringify(cartDataObject));
    resolve();
  } else {
    const tempDataStructure = {
      shoppingCart: [],
    };
    tempDataStructure.shoppingCart.push(_productDetails);
    localStorage.setItem('mycart', JSON.stringify(tempDataStructure));
    resolve();
  }
});

const modifyCart = (_product, response, type) => new Promise((resolve, reject) => {
  addItemTocart(_product);
  try {
    if (type === 'delete') {
      const foundIndex = response.findIndex((element) => element.skuId === _product.skuId);
      response.splice(foundIndex, 1);
      resolve(response);
    } else {
      response.forEach((element, index) => {
        if (element.skuId === _product.skuId) {
          response[index] = _product;
        }
      });
      resolve(response);
    }
  } catch (e) {
    logger.error('ERROR OCCURRED WHILE MOFIFYING THE CART');
    reject(e);
  }
});
const cartTotalCalculator = (FinalProductAdded) => {
  const cartTotal = FinalProductAdded && FinalProductAdded.length
  && FinalProductAdded.reduce((total, products) => total + (parseFloat(products.price, 0) * parseInt(products.quantity, 0)), 0);

  if (cartTotal) {
    return cartTotal.toFixed(2);
  }
  return cartTotal;
};
export {
  getShoppingCart, addItemTocart, modifyCart, cartTotalCalculator,
};
