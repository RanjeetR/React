/**
 * This function convert query params in url to
 * array of JSON objects.
 * @param {*} url url string
 */
const queryStringToJSONArray = (url) => {
  const params = [];
  const searchIndex = url.indexOf('?');

  if (searchIndex === -1) return params;
  const queryString = url.substring(searchIndex + 1);
  const urlVariables = queryString.split('&');
  for (let i = 0; i < urlVariables.length; i += 1) {
    const parameterName = urlVariables[i].split('=');
    params.push({ [parameterName[0]]: parameterName[1] });
  }
  return params;
};
/**
 * This function parse url according to selected/removed
 * facet item and return parsed url
 * @param {*} query current search part of url
 * @param {*} facet selected facet object
 */
const getParsedUrlForFilterHandle = (query, facet) => {
  let newQuery = '';
  newQuery = `${facet.facettype}=${facet.code}`;
  if (query === '') {
    return `?${newQuery}`;
  } if (query.indexOf(facet.code) === -1) {
    return `${query}&${newQuery}`;
  }
  let q = '';
  if (query.indexOf(`?${facet.facettype}`) !== -1) {
    q = query.replace(`?${facet.facettype}=${facet.code}`, '');
  }
  q = query.replace(`&${facet.facettype}=${facet.code}`, '');
  q = q.replace(`${facet.facettype}=${facet.code}`, '');
  if (q.indexOf('&') === 0) {
    q = q.replace('&', '');
  }
  if (q.indexOf('?&') !== -1) {
    q = q.replace('?&', '?');
  }
  return q;
};
export { queryStringToJSONArray, getParsedUrlForFilterHandle };
