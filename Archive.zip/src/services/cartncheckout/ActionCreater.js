import {
  FETCHCARTITEMS, ADDPRODUCT, UPDATEPRODUCT, ERROR, CLEARCART,
} from './ActionTypes';

// set action creators
export const initCart = () => ({ type: initCart });
export const fetchcartitems = (response) => ({ type: FETCHCARTITEMS, response });
export const addproduct = (response) => ({ type: ADDPRODUCT, response });
export const updateproduct = (response) => ({ type: UPDATEPRODUCT, response });
export const error = (response) => ({ type: ERROR, response });
export const clearcart = () => ({ type: CLEARCART });
