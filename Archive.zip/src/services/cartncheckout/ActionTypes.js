// define action types
export const FETCHCARTITEMS = 'FETCHCARTITEMS';
export const ADDPRODUCT = 'ADDPRODUCT';
export const UPDATEPRODUCT = 'UPDATEPRODUCT';
export const CLEARCART = 'CLEARCART';
export const ERROR = 'ERROR';
