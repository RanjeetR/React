/* eslint-disable no-shadow */
/* eslint-disable react/prop-types */
import React, { createContext, useReducer } from 'react';
import {
  FETCHCARTITEMS, ADDPRODUCT, UPDATEPRODUCT, ERROR, CLEARCART,
} from '../cartncheckout/ActionTypes';


export const cartDataStructure = {
  status: null,
  response: null,
};
const store = createContext(cartDataStructure);
const { Provider } = store;

const StateProvider = ({ children }) => {
  const [state, dispatch] = useReducer((state, { type, response }) => {
    switch (type) {
      case FETCHCARTITEMS:
        return { ...state, status: FETCHCARTITEMS, response };
      case ADDPRODUCT:
        return { ...state, status: ADDPRODUCT, response };
      case UPDATEPRODUCT:
        return { ...state, status: UPDATEPRODUCT };
      case ERROR:
        return { ...state, status: ERROR, response };
      case CLEARCART:
        return { ...cartDataStructure, status: CLEARCART };
      default:
        throw new Error();
    }
  }, cartDataStructure);

  return <Provider value={{ state, dispatch }}>{children}</Provider>;
};

export { store, StateProvider };
