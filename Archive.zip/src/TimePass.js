import React from 'react';
import TestComponent from './TestComponent';

const TimePass = () => {
  const myData = ['one', 'two', 'three', 'four'];
  return (
    <>
      <TestComponent options={myData} />
    </>
  );
};

export default TimePass;
