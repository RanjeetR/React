import { useReducer, useCallback } from 'react';
import axiosInstance from '../services/http/axiosConfig';
import APP_API from '../services/http/apiList';
// import axios from 'axios';
const useStateManagement = (apiname, { verb = 'get', params = {} } = {}, data_view_layer) => {
  // set endpont based on provided string
  const endpoint = APP_API[apiname];
  // set state and reducer
  const [state, dispatch] = useReducer(data_view_layer.reducer, data_view_layer.initialState);

  // method to invoke request
  const makeRequest = useCallback(async () => {
    dispatch(data_view_layer.fetching());
    try {
      let response = await axiosInstance[verb](endpoint, params);
      response = await response.data;
      dispatch(data_view_layer.success(response));
    } catch (e) {
      dispatch(data_view_layer.error(e));
    }
  }, [data_view_layer, verb, endpoint, params]);

  const filterRequest = useCallback(async (item) => {
    try {
      dispatch(data_view_layer.filter(item));
    } catch (e) {
      dispatch(data_view_layer.error(e));
    }
  }, [data_view_layer]);

  return [state, makeRequest, filterRequest];
};

export default useStateManagement;
