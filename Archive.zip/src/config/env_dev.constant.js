const constant = {
  enableVoiceSearch: true,
  enableLogs: true,
  enableDefaultExpandedFilterView: true,
};
export default constant;
