/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import InstagramIcon from '@material-ui/icons/Instagram';
import FacebookIcon from '@material-ui/icons/Facebook';
import PinterestIcon from '@material-ui/icons/Pinterest';
import YouTubeIcon from '@material-ui/icons/YouTube';
import { uid } from 'react-uid';
import './AppFooter.scss';

const AppFooter = ({ options }) => {
  const { sections } = options;
  return (
    <>
      <footer className="main-footer-section">
        {
         sections.map((category) => (
           <div className="footer-links-container" key={uid(category)}>
             <h3 className="footer-category">
               {' '}
               { category.title}
             </h3>
             <ul className="footer-links">

               {category.items.map((link) => (<li key={uid(link)}>{link.text}</li>))}
             </ul>
           </div>
         ))
      }

        <section className="footer-links-container">
          <a><FacebookIcon className="social-icon" /></a>
          <a><InstagramIcon className="social-icon" /></a>
          <a><PinterestIcon className="social-icon" /></a>
          <a><YouTubeIcon className="social-icon" /></a>
        </section>
      </footer>

    </>
  );
};

export default AppFooter;
