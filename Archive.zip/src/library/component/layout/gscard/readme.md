GSCard Component

Overview:-
GSCard component is use to create  a product card with various text data and style option.
    
How to use:-
    // import GSCard component  
    import GSsearchBox from 'gscard';
    // Define GSCard tag with appropriate props
    <GSCarousel 
       productUrl={"image-url"} header={"header-text"} productTitle={"product-title"} detail={"product-description"} productPrice={"$200"} action={true} actionData={actionDataobject} blendMode={true}
    />   
   
GSCard contain the following props-
        1. productUrl  : contains image url value for the product card.
        2. header      : contains text value to show on the product header.
        3. productTitle: to show product title on the card.
        4. detail      : to show product description on the card.
        5. productPrice: to show product price.
        6. action      : to show action buttons on the card.
        7. actionData  : An array of object for passing multiple action item which contains following properties:-
                 [
                        {
                        "label":"button1"
                        "url":"#someUrl",
                        "backgroundColor":"",
                        "color":""
                        },
                        {
                        "label":"button2"
                        "url":"#someUrl",
                        "backgroundColor":"",
                        "color":""
                        }
                 ]
          8. blendMode : To enable background color blending effect with the product image.

 


                           