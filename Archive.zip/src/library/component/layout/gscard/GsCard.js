
/* eslint-disable react/prop-types */
/* eslint-disable react/destructuring-assignment */
import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import classNames from 'classnames';
import './GsCard.scss';
import 'react-lazy-load-image-component/src/effects/blur.css';

export default function GSCard(props) {
  const useStyles = makeStyles({
    root: {
      height: props.height ? props.height : 'auto',
      width: props.width ? props.width : 'auto',
      textAlign: props.alignment ? props.alignment : 'center',
      margin: props.margin ? props.margin : 0,
      padding: props.padding ? props.padding : 0,
    },
    media: {
      height: props.height ? props.height : 'auto',
      width: props.width ? props.width : 'auto',

    },
  });
  const classes = useStyles();

  return (
    <div className={classNames(classes.root)}>
      <Card className={classNames(props.className, props.blendMode ? 'image-wrapper gs-card' : 'gs-card')}>
        {props.header
         && (
         <Typography variant="h5" component="h2">
           {props.header}
         </Typography>
         )}


        <LazyLoadImage
          src={props.productUrl}
          effect="blur"
          alt="not found"
          className={classNames(classes.media, props.blendMode ? 'background-color-effect' : '')}
        />
        <Card className="no-border-effect no-box-shadow-effect">
          {(props.productTitle || props.productPrice || props.detail)
          && (
          <CardContent>
            {props.productTitle
            && (
            <Typography variant="h5" component="h2">
              {props.productTitle}
            </Typography>
            )}

            {props.detail
            && (
            <Typography variant="body2" color="textPrimary" component="p">
              {props.detail}
            </Typography>
            )}

            {props.productPrice
            && (
            <Typography variant="h6" color="textSecondary" component="p">
              $
              {props.productPrice}
            </Typography>
            )}


          </CardContent>
          )}

          {props.action === true
          && (
          <CardActions>
            {props.actionData.map((item) => (
              <Button size="small" href={item.url} style={{ backgroundColor: item.backgroundColor ? item.backgroundColor : 'grey', color: item.color ? item.color : 'black' }}>
                {item.label}
              </Button>
            ))}
          </CardActions>
          )}
        </Card>
      </Card>
    </div>
  );
}
