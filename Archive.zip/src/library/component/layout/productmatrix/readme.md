GSProductMatrix Component

Overview:-
GSProductMatrix is a component which enables the developer to use to render provided products.

How to use:-
    // import GSProductMatrix component  
    import GSProductMatrix from 'GSProductMatrix';
    // Define GSProductMatrix tag with appropriate props
    <GSProductMatrix 
        products={products} 
        isLoading={isLoading}
    />

GSProductMatrix contains two props
    * products 
    * isLoading

products- 
It represents array of products.

isLoading-
It represent boolean value if products to be rendered are available.  


    
        

                           