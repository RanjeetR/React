
import React from 'react';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import staticContent from '../../../../localisation/en/staticContent';
import { GSMatGridItem, GSMatGridConatiner } from '../gsgrid/CustomGrid';
import Spinner from '../../feedback/spinner/Spinner';


export default function ProductMatrix({ isLoading, products }) {
  return (
    <>
      <GSMatGridItem xsCol={12} smCol={7} mdCol={8} lgCol={8} xlCol={8}>
        <Typography
          variant="h6"
          color="textSecondary"
          className="products-text"
        />
        <section className="all-product-label">
          <div className="top-product-label">
            {' '}
            {staticContent.productsCountText}
            {' '}
            {' '}
            {isLoading === false
              ? ` (${products.length})`
              : ''}
          </div>
          <Divider light />
        </section>
        {/* Show Loader */}
        { isLoading === true
          ? <Spinner isLoading={isLoading} />
          : (
            <GSMatGridConatiner spacing={0} align="center">
              {products.length ? (
                products
              ) : (
                <Typography className="empty-text">
                  {isLoading === false
                    ? staticContent.noProductsFoundMessage
                    : ''}
                </Typography>
              )}
            </GSMatGridConatiner>
          )}
      </GSMatGridItem>
    </>
  );
}
