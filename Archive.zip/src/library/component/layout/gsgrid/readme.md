GSMatGridConatiner and GSMatGridItem Components

Overview:-
GSMatGridConatiner and GSMatGridItem Components enables the developer to show repeated elements in specific row and column view. GSMatGridConatiner and  GSMatGridItem internally uses material ui Grid component which is based on a 12-column grid layout.

There are two types of layout: containers and items.
Item widths are set in percentages, so they’re always fluid and sized relative to their parent element.
Items have padding to create the spacing between individual items.
There are five grid breakpoints: xsCol, smCol, mdCol, lgCol, and xlCol.
GSMatGridConatiner is parent of GSMatGridItem component.

How to use:-
    // import GSMatGridConatiner and GSMatGridItem component  
    import {GSMatGridConatiner, GSMatGridItem} from 'GSMatGrid';
    // Define GSMatGridConatiner and GSMatGridItem tag with appropriate props
    <GSMatGridConatiner spacing={1} align="center">
        <GSMatGridItem xsCol={12} smCol={6} mdCol={4} lgCol={3} xlCol={2} className="center">
            <img src="https://assets.myntassets.com/dpr_2,q_60,w_210,c_limit,fl_progressive/assets/images/11002022/2020/2/7/177f13e4-f72c-453f-b49f-2ff07ca4830f1581047327297-DressBerry-Women-Tops-6771581047325196-1.jpg" />
        </GSMatGridItem>
        <GSMatGridItem xsCol={12} smCol={6} mdCol={4} lgCol={3} xlCol={2} className="center">
            <img src="https://assets.myntassets.com/dpr_2,q_60,w_210,c_limit,fl_progressive/assets/images/11002022/2020/2/7/177f13e4-f72c-453f-b49f-2ff07ca4830f1581047327297-DressBerry-Women-Tops-6771581047325196-1.jpg" />
        </GSMatGridItem>
    </GSMatGridContainer>

GSMatGridContainer accepts fallowing props
*spacing
*align

spacing 
It is number to specify spacing between GSMatGridItem

align={'left'| 'right' | 'center'} to align GSMatGridItem

GSMatGridItem accepts fallowing breakpoint props
*xsCol
*smCol
*mdCol
*lgCol
*xlCol
This all break points props accepts numbers 1 to 12 as per required view.

Each breakpoint (a key) matches with a fixed screen width (a value):

xsCol, extra-small: 0px
smCol, small: 600px
mdCol, medium: 960px
lgCol, large: 1280px
xlCol, extra-large: 1920px

These breakpoint values are used to determine breakpoint ranges. A range starts from the breakpoint value inclusive, to the next breakpoint value exclusive:

value         | 0px      600px    960px    1280px   1920px
key           | xsCol    smCol    mdCol    lgCol    xlCol
screen width  |--------|--------|--------|--------|-------->
range         | xsCol  | smCol  | mdCol  | lgCol  | xlCol
