import React from 'react';
import Grid from '@material-ui/core/Grid';

function GSMatGridItem({
  xsCol, smCol, mdCol, lgCol, xlCol, children,
}) {
  return (
    <Grid
      item
      xs={xsCol || 6}
      sm={smCol || 4}
      md={mdCol || 3}
      lg={lgCol || 2}
      xl={xlCol || 2}
    >
      {children}
    </Grid>
  );
}
function GSMatGridConatiner({ spacing, align, children }) {
  let justify = align || 'flex-start';
  if (justify === 'left') {
    justify = 'flex-start';
  } else if (justify === 'right') {
    justify = 'flex-end';
  }
  return (
    <Grid
      container
      spacing={spacing || 0}
      justify={justify}
      direction="row"
    >
      {children}
    </Grid>
  );
}
export { GSMatGridItem, GSMatGridConatiner };
