/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/interactive-supports-focus */
/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/prop-types */
import React from 'react';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';


import './priceSelector.scss';

export default function GSPriceSelector(props) {
  const [selectedPrice, setSelectedPrice] = React.useState('');
  function handlePriceChange(price) {
    setSelectedPrice(price.code);
    if (typeof props.onClick === 'function') { props.onClick(price); }
  }

  return (
    <div className="priceChartContainer commonAlignment">
      {props.showActivePriceText === 'true' && (
      <div id="priceText">
        {' '}
        {`Selected Price: ${selectedPrice}`}
      </div>
      )}
      { props.priceOptions.map((item) => {
        // const classes = item.selected.toString() === 'true' ? 'price-selector active' : 'price-selector';
        const classes = selectedPrice === item.code ? 'price-selector active' : 'price-selector';

        // const classes = (selectedPrice === item.code && toggleFacetsActivator.priceFacetsActivator.toString() === 'true') ? 'price-selector active' : 'price-selector';
        return (
          <div
            key={item.code}
          >
            <FormControlLabel
              control={(
                <Checkbox
                  name="price"
                  color="primary"
                  onChange={() => handlePriceChange(item)}
                />
              )}
              label={item.code}
            />
            {/* <span className="price-label">
              {item.code}
            </span> */}
          </div>
        );
      })}
    </div>
  );
}
