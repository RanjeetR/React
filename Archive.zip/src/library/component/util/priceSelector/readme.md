GSPriceSelector Component

Overview:-
GSPriceSelector is a component which enables the developer to use for filtering the products by their price.

How to use:-
// import GSPriceSelector component  
    import GSPriceSelector from 'PriceSelector';
    // Define GSPriceSelector tag with appropriate props
    <GSPriceSelector 
        onClick={handleFilterChange} 
        showActivePriceText="false" 
        priceOptions={filters}
    />

GSPriceSelector contains three props-
    * priceOptions
    * onClick 
    * showActivePriceText 

priceOptions- 
It consumes array of prices data like how many price range available to show on the page. And this array contains objects of price related properties eg--
            [{
            "name": "LessThanFifty",
            "code": "< $50",
            "min": 0,
            "max": 50,
            "matches": 20,
            "facettype": "price"
        }, ...]

onClick- 
It consumes on click handler method like-
    onClick={handleFilterChange}
which returns selected price facet object eg-
        {
            "name": "LessThanFifty",
            "code": "< $50",
            "min": 0,
            "max": 50,
            "matches": 20,
            "facettype": "price"
        }

showActivePriceText- 
It takes boolean value true/false to show selected price name above the price filter (Selected price: LessThanFifty) if value is true and vice versa.


    
        

                           