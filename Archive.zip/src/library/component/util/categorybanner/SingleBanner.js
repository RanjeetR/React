/* eslint-disable react/prop-types */
/* eslint-disable jsx-a11y/alt-text */
import React from 'react';
import Typography from '@material-ui/core/Typography';
import Hidden from '@material-ui/core/Hidden';
import { GSMatGridItem } from '../../layout/gsgrid/CustomGrid';

export default function SingleBanner({ options }) {
  return (
    <GSMatGridItem xsCol={12} smCol={12} mdCol={12} lgCol={12} key={options.index}>
      <div className="singleImgaeHolder">
        <div className="imageLayer-notransition">
          <picture>
            <source media="(min-width: 800px)" srcSet={options.item.source} />
            <source media="(min-width: 280px)" srcSet={options.item.secondaryImage} />
            <img src={options.item.source} alt={options.item.title} />

          </picture>

        </div>

        <div className="single-btext-layer">
          <div className="text">
            <a href="/mens-clothing/?icpa=hp&amp;icid=subhero&amp;icsa=spr20&amp;prid=visnav&amp;crid=mens-text" target="_self">

              <Typography variant="h4">
                {options.item.title}
              </Typography>
              <Hidden only={['xs']}>
                <Typography variant="subtitle1">
                  {options.item.description}
                </Typography>
              </Hidden>
            </a>
          </div>
        </div>
      </div>
    </GSMatGridItem>
  );
}
