/* eslint-disable react/prop-types */
/* eslint-disable jsx-a11y/alt-text */
import React from 'react';
import { uid } from 'react-uid';
import { GSMatGridConatiner } from '../../layout/gsgrid/CustomGrid';
import BannerItem from './BannerItem';
import SingleBanner from './SingleBanner';
import './CategoryBanner.scss';

const CategoryBanner = ({ options }) => {
  // get cat item rendered
  const getCatergoryRendered = options !== null
    && options.data
    && options.data.length
    && options.data.map((item, i) => (
      <BannerItem
        options={{
          item, index: i, stackText: options.stackText, circular: options.circularImage || false,
        }}
        key={uid(item)}
      />
    ));
    // get cat item rendered
  const getSingleBannerRendered = options !== null
  && options.data
  && options.data.length
  && options.data.map((item, i) => (
    <SingleBanner options={{ item, index: i, stackText: options.stackText }} key={i} />
  ));
  return (
    <div>
      <GSMatGridConatiner spacing={3} align="center">
        {options.singleBanner ? getSingleBannerRendered : getCatergoryRendered }
      </GSMatGridConatiner>
    </div>
  );
};


export default CategoryBanner;
