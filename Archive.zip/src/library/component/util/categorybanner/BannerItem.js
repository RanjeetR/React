
/* eslint-disable jsx-a11y/alt-text */
import React from 'react';
import { GSMatGridItem } from '../../layout/gsgrid/CustomGrid';

import './CategoryBanner.scss';

export default function BannerItem({ options }) {
  return (
    <GSMatGridItem xsCol={12} smCol={6} mdCol={3} lgCol={3} key={options.index}>
      <div className="categoryHolder">
        <div className={options.stackText ? 'imageLayer' : 'imageLayer-notransition'}>
          <a href={options.item.categoryUrl} target="_self">
            <img src={options.item.source} alt={options.item.title} className={options.circular ? 'circular-image' : ''} />
          </a>
        </div>

        <div className={options.stackText ? 'textLayer' : 'text-below'}>
          <div className="text">
            <a href={options.item.categoryUrl} target="_self">
              {options.item.title}
            </a>
          </div>
        </div>
      </div>
    </GSMatGridItem>
  );
}
