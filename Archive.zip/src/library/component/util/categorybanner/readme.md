# Category Banner component

# Features!
You can use this component to achive:
  - Showing categories in the grid, default option lg = 4, md = 4, sm = 2, xm =1
  - Component can render circular images for showing the product catergory.
  - Can be used to show single banner image.
  - Fully responsive.


### options need to pass to the component
    * data - accepts object containg image source, title, description !
    * stackText - #Boolean - This option can be used to show text stacked on image if true, else                 it will be  shown on the bottom.
    * showMoreIcon - #Boolean - TO show or hide show more button.
    * singleBanner - #Boolean - To show single image banner


### Example


```sh
<section className="section-wrapper">
        <Typography gutterBottom variant="h3" component="h3"   align="center">{staticContent.GetInspired}</Typography>
        <CategoryBanner options={
                 {
                    data: homepageData.data.forkidos,
                    stackText: false,
                    showMoreIcon: false,
                }
            }
        />
          </section>
```


**GSPANN UI TEAM**

