# GSRating Component

### Overview

**GSRating** component is a star rating component. This component internally uses the [Material-ui rating](https://material-ui.com/components/rating/) component. This component uses the **0.1** fraction for giving a rating and currenty it is **read only** in nature i.e. The rating value can be set through props only. This component is under development.


### import

``` javascript
import GSRating from 'path/to/GSRating/component';
```

### Props


| Name          |    Type       | Type Value     |  Default |  Description                                       |
| ------------- |:-------------:| --------------:|---------:|--------------------------------------------------: |
| rating        |  object       |   rating       |   0      |  Default rating given                              |
|               |               |  reviewCount   |   none   |  (optional) Total number of review to be displayed |
|               |               |  reviewComment |   none   |  (optional) Comment need to be passed to component |
|               |               |  ratingBase    |   5      |  (optional) rating scale                           |


### Example

``` javascript
    const ratingOpt = {
        'rating': 4.4,
        'reviewCount': 209,
        'reviewComment':  '14 out of 17 (82%) reviewers recommend this product',
        'ratingBase': 10
    }

    const App = () => {
        return(
            <GsRating rating={ratingOpt} />
        )
	};

    export default App;
```



