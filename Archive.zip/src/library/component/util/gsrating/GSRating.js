import React from 'react';
import Rating from '@material-ui/lab/Rating';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/core/styles';


const useStyles = makeStyles(() => ({
  inline: {
    display: 'inline-block',
    verticalAlign: 'top',
  },
}));

export default function GsRating(props) {
  const classes = useStyles();
  const {
    rating: {
      rating,
      reviewCount,
      reviewComment,
      ratingBase
    }
  } = props;

  return (
    <div className="gsrating-wrapper">
      <Box mb={3} borderColor="transparent">
        <Rating name="read-only" precision={0.1} value={rating} max={ratingBase || 5} readOnly />
        {rating ? (
          <Typography variant="body1" className={classes.inline}>
            {rating}
          </Typography>
        ) : null }
        {reviewCount ? (
          <Typography variant="body1" className={classes.inline}>
            {` |  ${reviewCount}  Reviews` }
          </Typography>
        ) : null }
        {reviewComment ? (
          <Typography variant="body1" className="reviewCommennt-value">
            {reviewComment}
          </Typography>
        ) : null }
      </Box>
    </div>
  );
}
