GSstoreLogo Component

Overview:-
GSstoreLogo is use to create a logo component for the header of the application.

How to use:-
// import GSstoreLogo component  
    import GSstoreLogo from 'gsStorelogo';
// Define GSstoreLogo tag with appropriate props
    <GSstoreLogo
     logo={"/images/gspannLogo.svg"} 
     alt="gspann logo"
     heightForDesktop="35px"
    heightForMobile="30px"
    />

GSPriceSelector contains followings props-
   1. logo : contains image url for the brand logo.
   2. alt  : contains alt text for the logo.
   3. heightForDesktop : to set logo height for desktop ,
   4. heightForMobile(optional)  : to set logo height for mobile ,
   
    