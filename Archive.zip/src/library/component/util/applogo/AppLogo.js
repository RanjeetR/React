import React from 'react';
import Hidden from '@material-ui/core/Hidden';

export default function AppLogo({
  logo, altText, heightForDesktop, heightForMobile,
}) {
  return (
    <>
      <Hidden only={['xs', 'sm']}>
        <div>
          <img src={logo} alt={altText} height={heightForDesktop} />
        </div>
      </Hidden>

      <Hidden only={['md', 'lg', 'xl']}>
        <div>
          <img src={logo} alt={altText} height={heightForMobile || heightForDesktop} />
        </div>
      </Hidden>
    </>
  );
}
