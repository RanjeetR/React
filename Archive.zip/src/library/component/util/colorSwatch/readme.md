ColorSwatch Component

Overview:-
ColorSwatch is a component which enables the developer to use for filtering the products by their color.

How to use:-
    // import GSColorSwatch component  
    import GSColorSwatch from 'ColorSwatch';
    // Define GSColorSwatch tag with appropriate props
    <GSColorSwatch 
        onClick={handleFilterChange} 
        showActiveColorText="false" 
        colorFacets={filters}
    />

GSColorSwatch contains three props
    * colorFacets
    * onClick 
    * showActiveColorText 

colorFacets- 
It consumes array of color facets like how many colors are available to show on the page. And this array contains objects of color related properties eg-
            [{
            "name": "Red",
            "code": "red",
            "matches": 24,
            "facettype": "color"
        }, ...]

onClick- 
It consumes onclick handler method like-
    onClick={handleFilterChange}
which returns selected color facet object eg-
        {
            "name": "Red",
            "code": "red",
            "matches": 24,
            "facettype": "color"
        }

showActiveColorText- 
It takes boolean value true/false to show selected color name above the color filter (Selected Color: Green) if value is true and vice versa.


    
        

                           