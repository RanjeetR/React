/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/prop-types */
import React, { useState, useContext } from 'react';
import Tooltip from '@material-ui/core/Tooltip';
import './ColorSwatch.scss';
// eslint-disable-next-line import/no-cycle
import { PdpContext } from '../../../../views/productpage/product';

export default function GSColorSwatch(props) {
  const { preSelectedColor, showActiveColorText } = props;
  const [selectedColor, setSelectedColor] = useState(preSelectedColor);
  const showActiveColorTextTruthy = showActiveColorText === 'true';
  const { PageType, filterRequest } = useContext(PdpContext) || {};
  const isPDPSwatch = PageType === 'Product';

  function handleColorChange(item) {
    setSelectedColor(item.name);
    if (typeof props.onClick === 'function') { props.onClick(item); }
  }
  const colors = () => (props.colorFacets.map((item) => {
    // debugger;
    // let classes = item.selected.toString() === 'true' ? 'color-selector activatedColor' : 'color-selector';
    let classes = selectedColor === item.name ? 'color-selector activatedColor' : 'color-selector';
    classes = props.className ? `${props.className} ${classes}` : classes;
    return (
      <div className={classes} key={item.code}>
        <Tooltip
          key={item.code}
          title={item.name}
          placement="top-start"
        >
          <span
            onClick={() => {
              handleColorChange(item);
              if (isPDPSwatch) filterRequest({ type: 'FILTER', color: item.name });
            }}
            className="colorItem "
            style={{ backgroundColor: item.code }}
            tabIndex={0}
            role="button"
            onKeyDown={() => handleColorChange(item)}
            aria-label="Save"
          />
        </Tooltip>
      </div>
    );
  })
  );
  return (
    <div className="colorSelectorContainer commonAlignment">
      { showActiveColorTextTruthy && (
      <div id="colorText">
        {' '}
        {`Selected Color: ${selectedColor}`}
      </div>
      )}
      {colors()}
    </div>
  );
}
