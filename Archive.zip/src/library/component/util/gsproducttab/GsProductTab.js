
import React, { useState } from 'react';
// Material UI components imported '
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';

const TabPanel = (props) => {
  const { children, value, index } = props;

  return (
    <Typography
      component="div"
      role="tabpanel"
      hidden={value !== index}
      id={`tab-${index}`}
      aria-labelledby={`tabpanel-${index}`}
    >
      {value === index && <Box p={3}>{children}</Box>}
    </Typography>
  );
};

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    width: '100%',
    backgroundColor: theme.palette.background.paper,
  },
  transparentBar: {
    backgroundColor: 'transparent !important',
    boxShadow: 'none',
  },
}));

const GsProductTab = (props) => {
  const classes = useStyles();
  const { availableAccordions } = props;
  const [value, setValue] = useState(0);

  /**
   * Handling the tab change
   * @param {*} event
   * @param {*} newValue
   */
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <div className={classes.root}>
      <AppBar
        position="static"
        color="default"
        className={classes.transparentBar}
      >
        <Tabs
          value={value}
          onChange={handleChange}
          TabIndicatorProps={{
            style: {
              backgroundColor: '#000000',
            },
          }}
          variant="scrollable"
          scrollButtons="auto"
          aria-label="product-information-tab"
        >
          {availableAccordions.map((elem, index) => <Tab label={elem.label} key={elem.label} id={`tabpanel-${index}`} aria-controls={`tab-${index}`} />)}
        </Tabs>
      </AppBar>
      {
        availableAccordions.map((elem, index) => (
          <TabPanel key={elem.label} value={value} index={index}>
            {elem.details}
          </TabPanel>
        ))
      }
    </div>
  );
};

export default GsProductTab;
