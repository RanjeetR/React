GSCarousel Component

Overview:-
GSCarousel component is use to create an animated carousel with dynamic data.
    
How to use:-
    // import GSCarousel component  
    import GSsearchBox from 'gscarousel';
    // Define GSBreadcumb tag with appropriate props
    <GSCarousel 
        slides={slides} autoPlay={true}
    />

GSBreadcumb contain the following props-
   1.  * slides :
                It consumes an array of slide-related objects which contain the following properties.
                    note:(desktopSource and mobileSource are the required properties.)
                            [
                        {
                            "desktopSource": "/images/slide_1_desktop.webp",
                            "mobileSource": "/images/slide_1_mobile.webp",
                            "title":"Skip the gym,",
                            "description":"not the workout.",
                            "actionText":"Shop now",
                            "actionUrl":"/search",
                            "textAlign":"Left",
                            "fontColor": "#fff"
                        },
                        {
                            "desktopSource": "/images/slide_2_desktop.webp",
                            "mobileSource": "/images/slide_2_mobile.webp",
                            "title":"Your new ,",
                            "description":"corner office.",
                            "actionText":"Shop now",
                            "actionUrl":"/search",
                            "textAlign":"left",
                            "fontColor": "#fff"
                        },
                    ],


 2.  autoPlay : consumes boolean value to enable auto play for slides.


                           