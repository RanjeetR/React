/* eslint-disable react/jsx-props-no-spreading */

import React from 'react';
// External node modules
import Slider from 'react-slick';
import { uid } from 'react-uid';
// material ui imports
import Hidden from '@material-ui/core/Hidden';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import Button from '@material-ui/core/Button';
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';
// Library Components
import { GSMatGridConatiner, GSMatGridItem } from '../../layout/gsgrid/CustomGrid';


import './MediaCarrousel.scss';

function MediaCarrousel({ options, settings }) {
  if (typeof options.data === 'undefined') {
    return 'Loading...';
  }

  // slides to be shown on slider depending on view port
  const slides = options.data.map((slide) => (
    <div className="slide" key={uid(slide)}>
      <Typography component="div" className="slide-content">
        {slide.title
          ? (
            <Box textAlign={slide.textAlign} className="title-text">
              <h1 style={{ color: slide.fontColor }}>{slide.title}</h1>
            </Box>
          ) : ''}
        {slide.description
          ? (
            <Box textAlign={slide.textAlign} className="description-text" style={{ color: slide.fontColor }}>
              {slide.description}
            </Box>
          ) : ''}
        {slide.actionUrl
          ? (
            <Box textAlign={slide.textAlign} className="action-text">
              <Button variant="outlined">
                <a href={slide.actionUrl}>{slide.actionText}</a>
                <ArrowForwardIosIcon style={{ fontSize: '10px' }} />
              </Button>
            </Box>
          ) : ''}
      </Typography>

      {/* Destop View - Background Image */}
      <Hidden only={['xs', 'sm']}>
        <img alt={slide.title} src={slide.backgroundImages.desktop} className="carousel-image" />
      </Hidden>

      {/* Tablet View - Background Image */}
      <Hidden only={['xs', 'md', 'lg', 'xl']}>
        <img alt={slide.title} src={slide.backgroundImages.tablet} className="carousel-image" />
      </Hidden>

      {/* Mobile View - Background Image */}
      <Hidden only={['sm', 'md', 'lg', 'xl']}>
        <img alt={slide.title} src={slide.backgroundImages.mobile} className="carousel-image" />
      </Hidden>

    </div>
  ));
  return (
    <GSMatGridConatiner>
      <GSMatGridItem xsCol={12} mdCol={12} smCol={12} lgCol={12}>
        {/* Can we avoid spreeding so unintentional extra props will not be passed */}
        <div className="gs-carousel">
          <Slider {...settings}>
            {slides}
          </Slider>
        </div>
      </GSMatGridItem>
    </GSMatGridConatiner>

  );
}
export default MediaCarrousel;
