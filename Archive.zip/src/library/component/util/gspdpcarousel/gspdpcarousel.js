import React, { useRef } from 'react';
import Slider from 'react-slick';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

import './gspdpcarousel.scss';

export default function GSPdpCarousel(props) {
  const { selecteditem, allitems } = props;
  const filteredSlides = allitems.filter((items) => items.code === selecteditem);
  const noOfFilteredSlides = filteredSlides[0].productSlides.length;
  const sliderRef = useRef(0);
  const handleNextSlide = () => {
    sliderRef.current.slickPrev();
  };
  const handlePrevSlide = () => {
    sliderRef.current.slickNext();
  };

  const productPageCarouselSettings = {
    customPaging(i) {
      return (
        <a href={i + 1} className="custom-pagination-controls">{i + 1}</a>
      );
    },
    className: 'slider variable-width',
    dots: true,
    infinite: true,
    slidesToShow: 2,
    slidesToScroll: 1,
    variableWidth: true,
    focusOnSelect: true,
    initialSlide: 0,
    arrows: true,
    appendDots: (pageNumber) => (
      <div>
        <span style={{ paddingInlineStart: '0', display: 'flex' }}>
          <button className="next-custom-arrow" aria-label="next-arrow" type="button" onClick={handleNextSlide}>
            <ArrowBackIosIcon />
          </button>
          { noOfFilteredSlides <= 6
          && (
          <ul className="slider-navigation-wide-view">
            {pageNumber}
          </ul>
          )}
          { noOfFilteredSlides > 6 && (
          <span className="slider-navigation-compact-view">
            {pageNumber}
            of
            {' '}
            <span>
              {' '}
              {noOfFilteredSlides}
              {' '}
            </span>
          </span>
          )}

          <button type="button" className="prev-custom-arrow" aria-label="prev-arrow" onClick={handlePrevSlide}>
            <ArrowForwardIosIcon />
          </button>

        </span>
      </div>
    ),
    responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          focusOnSelect: false,
          variableWidth: true,
          initialSlide: 0,

        },
      },
    ],
  };
  return (
    <div className="gspdpcarousel-wrapper">
      {
        filteredSlides && filteredSlides.length && filteredSlides[0].productSlides.length > 1
          ? (

            <Slider ref={sliderRef} {...productPageCarouselSettings}>
              {filteredSlides[0].productSlides.map((slide) => <img key={filteredSlides[0].code} alt={filteredSlides[0].name} src={slide.source} className="product-slides" />)}
            </Slider>
          )
          : <img alt={filteredSlides[0].name} className="product-single-slide" src={filteredSlides[0].productSlides[0].source} />
}
    </div>
  );
}
