/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/prop-types */
import React from 'react';
import Button from '@material-ui/core/Button';
import './sizeSelector.scss';

export default function GSSizeSelector(props) {
  const { preSelectedSize } = props;
  const [selectedSize, setSelectedSize] = React.useState(preSelectedSize);
  function handleSizeChange(size) {
    setSelectedSize(size.code);
    if (typeof props.onClick === 'function') { props.onClick(size); }
  }
  return (
    <div className="sizeChartContainer commonAlignment">
      {props.showActiveSizeText === 'true' && (
      <div id="sizeText">
        {' '}
        {`Selected: ${selectedSize}`}
      </div>
      )}
      {props.sizeOptions.map((item) => {
        // let classes = item.selected.toString() === 'true' ? 'sizeFilterButton activeButton' : 'sizeFilterButton';
        let classes = selectedSize === item.code ? 'sizeFilterButton activeButton' : 'sizeFilterButton';

        classes = props.className ? `${props.className} ${classes}` : classes;
        return (
          <Button
            id="size-btn"
            className={classes}
            onClick={() => {
              handleSizeChange(item);
            }}
            key={item.code}
            disabled={item.disabled}
          >
            {item.code}
            <div className="strikeoutLine"> </div>
          </Button>
        );
      })}
    </div>
  );
}
