GSSizeSelector Component

Overview:-
GSSizeSelector is a component which enables the developer to use for filtering the products by their size.

How to use:-
// import GSSizeSelector component  
    import GSSizeSelector from 'SizeSelector';
    // Define GSSizeSelector tag with appropriate props
    <GSSizeSelector 
        onClick={handleFilterChange} 
        showActiveSizeText="false" 
        sizeOptions={filters}
    />

GSSizeSelector contains three props-
    * sizeOptions
    * onClick 
    * showActiveSizeText 

sizeOptions- 
It consumes array of sizes like how many sizes available to show on the page. And this array contains objects of size related properties eg--
            [{
            "name": "Medium",
            "code": "md",
            "matches": 30,
            "facettype": "size"
        }, ...]

onClick- 
It consumes on click handler method like-
    onClick={handleFilterChange}
which returns selected size facet object eg-
        {
            "name": "Medium",
            "code": "md",
            "matches": 30,
            "facettype": "size"
        }

showActiveSizeText- 
It takes boolean value true/false to show selected size name above the size filter (Selected Size: Medium) if value is true and vice versa.


    
        

                           