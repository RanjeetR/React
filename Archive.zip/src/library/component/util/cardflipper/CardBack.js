import React from 'react';

const CardBack = (props) => (
    <div className="figureTwo"> {props.children} </div>
);


export { CardBack };
