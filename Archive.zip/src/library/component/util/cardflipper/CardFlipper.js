/* eslint-disable react/prop-types */
import React, { useState } from 'react';


const CardFlipper = ({ options, children }) => {
  const { width, height } = options;
  const [flip, setFlip] = useState(false);

  const flipMoveIn = () => {
    setFlip(true);
  };
  const flipMoveOut = () => {
    setFlip(false);
  };
  return (
    <div className="itemBoxWrapper" style={{ width, height }} onMouseEnter={flipMoveIn} onMouseLeave={flipMoveOut}>

      <div className="flipper" style={{ transform: flip ? 'rotateY(180deg)' : 'rotateY(0deg)' }}>
        {children}
      </div>

    </div>
  );
};
export { CardFlipper };
