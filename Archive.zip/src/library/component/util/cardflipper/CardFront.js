import React from 'react';

const CardFront = (props) => (
   <div className="figureOne"> {props.children} </div>
);


export { CardFront };
