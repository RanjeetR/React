# Flipper Component

### Overview

**Flipper Component** component can be used for flipping any DOM content such as images or thumbnails.
Currently this component supports rotation in 180degree only.

This component has 2 different sub components i.e **CardFront**  and **CardBack**.

**CardFront** takes front images or DIV.
**CardBack** takes back part of images or DIV.

Future scope:- The component will supports different rotation angles and orientation.


### import

``` javascript
import { CardFlipper, CardFront, CardBack } from 'pathto/cardflipper';
```

### Props


| Name          |    Type       |  Key     |  type |  Description                                       |
| ------------- |:-------------:| --------------:|---------:|--------------------------------------------------: |
| CardFlipper        |  object       |          |   0      |                               |
|               |               |  Width   |   Required   |  Width of the the content |
|               |               |  Height |   Required   |  Height of the the content |



### Example

``` javascript
   const flipperConfig = {
    width: '90px',
    height: '110px',
  };

  <CardFlipper options={flipperConfig}>
      <CardFront>
        <div className={classes.images}>
          <img src={item.imageSource} />
        </div>
      </CardFront>
      <CardBack>
        <div className="cart-wrapper-size">
        <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi lobortis congue malesuada.    Curabitur porttitor ante velit, sed tincidunt lorem feugiat et. Curabitur est metus, finibus vel neque ut, semper efficitur ipsum </p>
        </div>
      </CardBack>
    </CardFlipper>
```



