GSLoader Component

Overview:-
GSLoader is a component which enables the developer to show loader.

How to use:-
    // import GSLoader component  
    import GSLoader from 'GSLoader';
    // Define GSLoader tag with appropriate props
    <GSLoader 
        isLoading={true}
    />

GSLoader accepts one props
    * isLoading
    

isLoading- 
    isLoading is booloean value depending upon user can show or hide loader.