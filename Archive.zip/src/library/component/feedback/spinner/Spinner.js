
import React from 'react';
import CircularProgress from '@material-ui/core/CircularProgress';
import { GSMatGridItem, GSMatGridConatiner } from '../../layout/gsgrid/CustomGrid';

export default function Spinner({ isLoading }) {
  return (
    <>
      {isLoading === true ? (
        <GSMatGridConatiner spacing={0} align="center">
          <GSMatGridItem xsCol={12} className="center">
            <CircularProgress disableShrink />
          </GSMatGridItem>
        </GSMatGridConatiner>
      ) : (
        ''
      )}
    </>
  );
}
