import React from 'react';
import { uid } from 'react-uid';
// MUI components
import Paper from '@material-ui/core/Paper';
import Link from '@material-ui/core/Link';
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
// Style imports
import './Breadcrumb.scss';

export default function GSBreadcumb({ breadcrumbData }) {
  const BreadcumbLinks = breadcrumbData.map((item) => {
    let classes = 'breadcrumb-item';
    classes = item.active === true ? `${classes} active` : classes;
    return (
      <Link color="textPrimary" key={uid(item)} href={item.link} className={classes}>
        {item.linkName}
      </Link>
    );
  });
  return (
    <Paper id="breadcrumb">
      <Breadcrumbs aria-label="Breadcrumb">
        {BreadcumbLinks}
      </Breadcrumbs>
    </Paper>
  );
}
