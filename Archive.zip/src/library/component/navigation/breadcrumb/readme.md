GSBreadcumb Component

Overview:-
GSBreadcumb is a component which enables the developer to use for showing breadcumb on the page like:
    All/ Women / Tops

How to use:-
// import GSBreadcumb component  
    import GSBreadcumb from 'Breadcumb';
    // Define GSBreadcumb tag with appropriate props
    <GSBreadcumb 
        breadcrumbData={data}
    />

GSBreadcumb contain one props-
    * breadcrumbData

breadcrumbData- 
It consumes array of breadcumb data to show on the page. And this array contains objects of breadcumb related properties eg--
            [
                {   
                    "active": false,
                    "link": "/all",
                    "linkName": "All" },
                {   
                    "active": false,
                    "link": "/Women",
                    "linkName": "Women" },
                {
                    "active": false,
                    "link": "/tops",
                    "linkName": "Tops" }
            ]


    
        

                           