/* eslint-disable jsx-a11y/label-has-associated-control */
import React, { useState } from 'react';
// MUI components
import MenuIcon from '@material-ui/icons/Menu';
import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import CloseIcon from '@material-ui/icons/Close';
import ListSubheader from '@material-ui/core/ListSubheader';
import Button from '@material-ui/core/Button';
import { uid } from 'react-uid';
// scss file
import './MenuDropDowns.scss';

export default function MenuDropDowns({
  categories, width, heading, subHeading,
}) {
  const [slideOpen, setSlideOpen] = useState(false);
  const [selectedCatergory, setSelectedCatergory] = useState(null);
  const [subCatagoryList, setsubCatagoryList] = useState(null);

  const toggleDrawer = (open) => (event) => {
    if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }
    setSlideOpen(open);
  };
  // Display matching sub menu
  const displaySubCategories = (name, subCatagory) => {
    setSelectedCatergory(name);
    setsubCatagoryList(subCatagory);
  };
  // Get Main menu listing
  const getCategoryListing = categories
  && categories.length
  && categories.map((category, index) => (
    <ListItem
      key={uid(index)}
      onClick={() => { displaySubCategories(category.name, category.subCatagory); }}
    >
      <label className="categoryName">{category.name}</label>
      <ListItemIcon>
        <ArrowForwardIosIcon fontSize="small" />
      </ListItemIcon>
    </ListItem>
  ));

  const categoryMainList = () => (
    <div
      role="presentation"
      onClick={() => { toggleDrawer(false); }}
      onKeyDown={toggleDrawer(false)}
      className="list"
      style={{ width: width || '' }}
    >
      <List
        className="paddingZero"
        subheader={(
          <ListSubheader component="div" id="nested-list-subheader" className="menuContentBackground">
            <Button
              variant="text"
              startIcon={<CloseIcon onClick={toggleDrawer(false)} />}
              className="menuContentColor"
            >
              {' '}
              {heading}
            </Button>

          </ListSubheader>
    )}
      >
        {getCategoryListing}
      </List>
    </div>
  );
  const getSubCategoryList = subCatagoryList
 && subCatagoryList.length
    && subCatagoryList.map((category, index) => (
      <ListItem key={uid(index)}>
        <a href={`${category.url}`} className="itemColor">
          {category.name}
        </a>
      </ListItem>
    ));
  const categorySubList = () => (
    <div
      role="presentation"
      onClick={() => { toggleDrawer(false); }}
      onKeyDown={toggleDrawer(false)}
      className="list"
      style={{ width: width || '' }}
    >
      <List
        className="paddingZero"
        subheader={(
          <ListSubheader
            component="div"
            id="nested-list-subheader"
            className="menuContentBackground"
            onClick={() => {
              displaySubCategories(null);
            }}
          >
            <Button
              variant="text"
              startIcon={<ArrowBackIosIcon />}
              className="menuContentColor"
            >
              {subHeading}
            </Button>
          </ListSubheader>
   )}
      >
        {getSubCategoryList}
      </List>
    </div>
  );

  return (
    <>
      <Button
        variant="text"
        onClick={toggleDrawer(true)}
        startIcon={<MenuIcon />}
        aria-label="menu"
      >

        {' '}

      </Button>
      {selectedCatergory
        ? <Drawer open={slideOpen} onClose={toggleDrawer(false)}>{categorySubList()}</Drawer>
        : (
          <Drawer open={slideOpen} onClose={toggleDrawer(false)}>
            {categoryMainList()}
          </Drawer>
        )}
    </>
  );
}
