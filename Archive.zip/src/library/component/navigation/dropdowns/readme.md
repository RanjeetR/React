GSshopByCatagory Component

Overview:-
GSshopByCatagory is use to create a category dropdown with nested category options.

How to use:-
// import GSshopByCatagory component  
    import GSshopByCatagory from 'gsShopByCatagory';
// Define GSshopByCatagory tag with appropriate props
      <GSshopByCatagory
          heading={"SHOP-BY-DEPARTMENT"}
          categories={categories}
          width={'220px'}
      />

GSPriceSelector contains three props-
   
   1. heading:- contains a string value to display heading text for category dropdown list.
   2. categories:- contains category JSON data eg:-

             [
                  {
                    "url": "/catalog/d6969810-f798-4d16-86de-00ca21062a88",
                    "name": "Bed & Bath",
                    "subCatagory": [
                      {
                        "name": "Bedspreads",
                        "url": "/search/ad4a99df-2d55-42e3-aa55-0222e69fa856"
                      },
                      {
                        "name": "Blankets & Throws",
                        "url": "/search/48dd4813-9a9c-44ff-ba73-9a4b46a2b446"
                      },
                  },
                  {
                    "url": "/catalog/d6969810-f798-4d16-86de-00ca21062a88",
                    "name": "Bed & Bath",
                    "subCatagory": [
                      {
                        "name": "Bedspreads",
                        "url": "/search/ad4a99df-2d55-42e3-aa55-0222e69fa856"
                      },
                      {
                        "name": "Blankets & Throws",
                        "url": "/search/48dd4813-9a9c-44ff-ba73-9a4b46a2b446"
                      },
                  }
              ]

   3. width: to set the width of the category dropdown section.