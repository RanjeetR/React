
import React from 'react';
// Material UI components import
import Pagination from '@material-ui/lab/Pagination';

export default function StorePagination({
  page, handlePageChange, count,
}) {
  return (
    <section className="pagination">
      <Pagination
        page={page}
        onChange={handlePageChange}
        count={count}
        variant="outlined"
        shape="rounded"
      />
    </section>
  );
}
