GSPagination Component

Overview:-
GSPagination is a component which enables the developer to use for paginate items.

How to use:-
    // import GSPagination component  
    import GSPagination from 'GSPagination';
    // Define GSPagination tag with appropriate props
    <GSPagination
        page={page}
        handlePageChange={handlePageChange}
        count={5}
    />

GSPagination contains three props
    * page
    * handlePageChange 
    * count 

page- 
It represents current page.

handlePageChange-
Callback fired when the page is changed.
    Signature:
    function(event: object, page: number) => void
    event: The event source of the callback.
    page: The page selected.

count- 
It takes numbere value to show the total number of pages.



    
        

                           