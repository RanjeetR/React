import React, { useState, useEffect } from 'react';
// MUI componentss
import MicIcon from '@material-ui/icons/Mic';
// killswitch
import constant from '../../../../config/env_dev.constant';
import './VoiceSearch.scss';

const VoiceSearch = ({ getSearchText, continuousResult, endListening }) => {
  const [isVoiceSupported, setVoSupport] = useState(false);
  //   const [isTalking, setIsTalking] = useState(true);
  const [animated, setAnimate] = useState('');
  const { webkitSpeechRecognition } = window;
  const handleVoiceSearch = () => {
    const SpeechRecognition = webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    // To get continuous results
    if (continuousResult) {
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;
    }
    recognition.onresult = (event) => {
      const text = event.results[0][0].transcript || '';
      if (text) getSearchText(text);
    };
    recognition.start();
    setAnimate('animate-mic');
    recognition.onend = () => {
      setAnimate('');
      endListening();
    };
  };
  useEffect(() => {
    if (('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) && constant.enableVoiceSearch) {
      // speech recognition API supported
      setVoSupport(true);
    }
  }, []);
  return (
    <>
      {isVoiceSupported && (
        <div className={`mic ${animated}`}>
          <MicIcon
            onClick={handleVoiceSearch}
          />
        </div>
      )}
    </>
  );
};
export default VoiceSearch;
