/* eslint-disable no-unused-vars */
/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';
import { useHistory } from 'react-router-dom';
// MUI components
import InputAdornment from '@material-ui/core/InputAdornment';
import SearchIcon from '@material-ui/icons/Search';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { makeStyles } from '@material-ui/core/styles';
// style imports
import './SearchBox.scss';

const useStyles = makeStyles((theme) => ({
  option: {
    fontSize: 12,

  },
  noOptions: {
    fontSize: 12,
  },
  root: {
    display: 'none',
    [theme.breakpoints.down('sm')]: {
      display: 'inline-block',
    },
  },
}));
export default function SearchBox({ recentSearchItems, placeholder, searchText }) {
  const history = useHistory();
  const classes = useStyles();
  const handleInputChange = (_event, _value) => {
    // history.push(value.url);
    // this is getting fired only on clearing the text
  };


  return (
    <section className="gssearch-box-container">
      <Autocomplete
        id="combo-box-demo"
        options={recentSearchItems}
        getOptionLabel={(option) => (typeof option === 'string' ? option : option.name)}
        style={{ width: 'auto' }}
        onChange={handleInputChange}
        getOptionSelected={(option, value) => option.text === value.name}
        size="small"
        value={searchText}
        classes={{
          option: classes.option,
          noOptions: classes.noOptions,
        }}
        renderInput={(params) => {
          params.InputProps.endAdornment = (
            <InputAdornment position="end">
              <SearchIcon />
            </InputAdornment>
          );
          return (
            <TextField
              {...params}
              variant="outlined"
              label={placeholder}
              title="search"
              aria-label="search"
              fullWidth
            />
          );
        }}
      />

    </section>
  );
}
