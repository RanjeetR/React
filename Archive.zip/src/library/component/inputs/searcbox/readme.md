GSsearchBox Component

Overview:-
GSsearchBox component is use to create an autocomplete search box with dropdown options.
    
How to use:-
    // import GSsearchBox component  
    import GSsearchBox from 'gssearchbox';
    // Define GSBreadcumb tag with appropriate props
    <GSsearchBox 
        recentSearchItems={data}
    />

GSBreadcumb contain one props-
    * recentSearchItems

recentSearchItems- 
It consumes an array of recently search items data to show as a dropdown option. And this array contains objects of recent search-related properties eg--
            [
                {
                    "name": "Coats & Jackets",
                    "url": "/search/a817a265-4f26-4817-86f3-d5cf9d75d381"
                },
                {
                    "name": "Dress Shirts",
                    "url": "/search/7a6cab13-16a9-4e78-aaad-fa34c70aa677"
                },
                {
                    "name": "Graphic Tees",
                    "url": "/search/9d77105e-e4bd-4acd-8c1f-cfe53f37b339"
                },
                {
                    "name": "Hoodies & Sweatshirts",
                    "url": "/search/49090fb0-58db-4667-903c-6441fdc9e98a"
                },
                {
                    "name": "Jeans",
                    "url": "/search/d2129eef-3347-44c0-8db2-f4bbb4f907b6"
                },
            ]


    
        

                           