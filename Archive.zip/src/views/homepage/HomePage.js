
import React, { useEffect, useState } from 'react';
// MUI components
import Typography from '@material-ui/core/Typography';
import { FormattedMessage } from 'react-intl';

// Library Components
import MediaCarrousel from '../../library/component/util/mediacarrousel/MediaCarrousel';
import CategoryBanner from '../../library/component/util/categorybanner/CategoryBanner';
import Spinner from '../../library/component/feedback/spinner/Spinner';

// Application components
import Footer from '../common/footer/Footer';
import AppHeader from '../common/header/AppHeader';

// API Methods
import { get } from '../../services/http/request';
import APP_API from '../../services/http/apiList';

// CSS File
import './HomePage.scss';

export default function HomePage() {
  const [homepageData, setHomepageData] = useState({ data: [], isDataLoaded: false });

  // Add page effects
  useEffect(() => {
    // retrieve data
    get(APP_API.homepage)
      .then((response) => {
        if (response && response.data) {
          setHomepageData({ data: response.data, isDataLoaded: true });
        }
      });
  }, []);
  const settings = {
    dots: true,
    infinite: true,
    speed: 1000,
    slidesToShow: 1,
    slidesToScroll: 1,
    initialSlide: 0,
    autoplay: false,
    // responsive settings for desktop, tablet and mobile
    // Find alternative approch, remove hardcoded breakpoints
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          dots: true,

        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          initialSlide: 1,
        },
      },
      {
        breakpoint: 320,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          dots: true,
          infinite: true,
          autoplay: true,
          autoplaySpeed: 1500,
        },
      },
    ],
  };

  return (
    <div>
      {/* Load view if data is suceessfully loaded */}

      {homepageData.isDataLoaded ? (
        <div>
          <section className="header-wrapper">
            <AppHeader options={{ headerAPI: APP_API.header }} />
          </section>

          <section className="carousel-wrapper">
            <MediaCarrousel options={{ data: homepageData.data.slides }} settings={settings} />
          </section>

          <section className="category-wrapper">
            <Typography gutterBottom variant="h3" component="h3" align="center">
              <FormattedMessage id="featured" defaultMessage="featured" />
            </Typography>
            <CategoryBanner options={
              {
                data: homepageData.data.jumbotron,
                stackText: true,
                showMoreIcon: false,
              }
              }
            />
          </section>

          <section className="category-wrapper">
            <Typography gutterBottom variant="h3" component="h3" align="center">
              <FormattedMessage id="NewArrival" defaultMessage="NewArrival" />
            </Typography>
            <CategoryBanner options={
              {
                data: homepageData.data.secondpListing,
                stackText: false,
                showMoreIcon: false,
                circularImage: true,
              }
              }
            />
          </section>
          <section className="category-wrapper">
            <CategoryBanner options={
              {
                data: homepageData.data.singleBannerItem,
                singleBanner: true,
              }
              }
            />
          </section>
          <section className="category-wrapper">
            <Typography gutterBottom variant="h3" component="h3" align="center">
              <FormattedMessage id="GetInspired" defaultMessage="GetInspired" />
            </Typography>
            <CategoryBanner options={
              {
                data: homepageData.data.forkidos,
                stackText: false,
                showMoreIcon: false,
              }
              }
            />
          </section>

          <section className="footer-wrapper">
            <Footer options={{ footerAPI: APP_API.footer_data }} />
          </section>
        </div>
      ) : (
        <section className="loader">
          {' '}
          <Spinner isLoading />
          {' '}
        </section>
      )}
    </div>
  );
}
