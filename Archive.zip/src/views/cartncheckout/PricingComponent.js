/* eslint-disable react/prop-types */
import React from 'react';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import { cartTotalCalculator } from '../../services/helpers/CartItemHelper';
import staticContent from '../../localisation/en/staticContent';

export default function PricingComponent({ FinalProductAdded }) {
  const getTotalPrice = () => <strong>{cartTotalCalculator(FinalProductAdded)}</strong>;
  return (
    <section className="checkout-container">
      <section className="cnc-price-section">
        <article className="checkout-inner-label">

          <Typography>Subtotal (2 items)</Typography>
          <Typography>Shipping</Typography>
          <Typography>Estimated Tax</Typography>
        </article>
        <article className="checkout-inner-price">
          <Typography>$105</Typography>
          <Typography>FREE</Typography>
          <Typography>$15</Typography>
        </article>
      </section>
      <article className="cart-total">
        <Typography variant="h6">Total</Typography>
      </article>
      <article align="right" className="cart-total">
        <Typography variant="h6">
          {staticContent.currenySign}
          {getTotalPrice()}
        </Typography>
      </article>
      <div className="checkout-btn-wrapper">
        <Button className="checkout-btn">Checkout</Button>
      </div>

    </section>
  );
}
