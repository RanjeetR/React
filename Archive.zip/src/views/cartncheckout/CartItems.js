/* eslint-disable no-param-reassign */
/* eslint-disable no-plusplus */
/* eslint-disable react/jsx-no-bind */
import React from 'react';
import { uid } from 'react-uid';
// MUI components
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import IconButton from '@material-ui/core/IconButton';
import { Add, Remove } from '@material-ui/icons';
// Static content
import staticContent from '../../localisation/en/staticContent';
// Actions
import { modifyCart } from '../../services/helpers/CartItemHelper';
import { FETCHCARTITEMS } from '../../services/cartncheckout/ActionTypes';

export default function CartItems({ SelectedProduct, dispatch }) {
  const changeQuantity = (type, item) => {
    if (type === 'add') {
      item.quantity++;
    } else if (item.quantity > 1) {
      item.quantity--;
    }
    modifyCart(item, SelectedProduct, type).then((data) => {
      dispatch({ type: FETCHCARTITEMS, response: data });
    });
  };

  return (
    <section>
      <Typography variant="h5" className="cart-name-wrapper">
        { staticContent.cartItemLabel }
        :
        {' '}
        {SelectedProduct && SelectedProduct.length}
        {' '}
        Items
      </Typography>
      {SelectedProduct && SelectedProduct.length && SelectedProduct.map((item) => (
        <section className="cart-item-container" key={uid(item)}>
          <article className="prodcut-image">
            <img src={item.imageSource} alt={item.title} />
          </article>
          <article className="product-desc">
            <Typography variant="h6">{item.title}</Typography>
            <Typography>
              Color:
              {item.skuId}
            </Typography>
            <Typography>
              Size:
              {item.skuId}
            </Typography>
          </article>
          <article className="product-qnty">
            <div className="product-quantity-buttons">
              <IconButton aria-label="decrease" size="medium" onClick={changeQuantity.bind(null, 'remove', item)}>
                <Remove />
              </IconButton>
              <Box className="product-quantity-amount">
                <Typography variant="h6" className="cart-product-qty">
                  {item.quantity}
                </Typography>
              </Box>
              <IconButton aria-label="increase" size="medium" onClick={changeQuantity.bind(null, 'add', item)}>
                <Add />
              </IconButton>
            </div>

          </article>
          <article className="product-price">
            <Typography variant="h6">
              {' '}
              {staticContent.currenySign}
              {item.price}
            </Typography>
          </article>
          <article className="product-remove">
            <Typography className="text-align-right">
              {' '}
              <button type="button" onClick={changeQuantity.bind(null, 'delete', item)}>{staticContent.cartItemRemoveLabel}</button>
              {' '}
              |
              {' '}
              <button type="button">{staticContent.cartSaveforLetter}</button>
            </Typography>
          </article>
        </section>
      ))}
    </section>
  );
}
