import React, { useContext } from 'react';
// Library Components
import { GSMatGridItem, GSMatGridConatiner } from '../../library/component/layout/gsgrid/CustomGrid';
// Application components
import Footer from '../common/footer/Footer';
import AppHeader from '../common/header/AppHeader';
// CnC components
import CartItems from './CartItems';
import PricingComponent from './PricingComponent';
// store
import { store } from '../../services/store/Store';
// API Methods
import APP_API from '../../services/http/apiList';
// Style imports
import './cartncheckout.scss';

export default function CartnCheckout() {
  const sharedState = useContext(store);
  const { state, dispatch } = sharedState;
  return (
    <>
      <section className="header-wrapper">
        <AppHeader options={{ headerAPI: APP_API.header }} />
      </section>
      <section className="cart-container">
        <div className="cart-page-wrapper">
          <GSMatGridConatiner spacing={0} align="center">
            <GSMatGridItem xsCol={12} smCol={12} mdCol={9} lgCol={9}>
              <CartItems SelectedProduct={state.response} dispatch={dispatch} />
            </GSMatGridItem>
            <GSMatGridItem xsCol={12} smCol={12} mdCol={3} lgCol={3}>
              <PricingComponent FinalProductAdded={state.response} />
            </GSMatGridItem>
          </GSMatGridConatiner>
        </div>
      </section>
      <section className="footer-wrapper">
        <Footer options={{ footerAPI: APP_API.footer_data }} />
      </section>
    </>
  );
}
