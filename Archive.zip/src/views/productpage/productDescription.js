
import React, { useState, useContext } from 'react';
// Material UI components imported  from '@material-ui/core/Grid';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import {
  FavoriteBorder, Compare, Add, Remove, ShoppingCart,
} from '@material-ui/icons';
import IconButton from '@material-ui/core/IconButton';
import Box from '@material-ui/core/Box';
import { FormattedMessage } from 'react-intl';

// import custom component
// eslint-disable-next-line import/no-cycle
import ColorSwatch from '../../library/component/util/colorSwatch/ColorSwatch';
// Library Components
import { GSMatGridItem, GSMatGridConatiner } from '../../library/component/layout/gsgrid/CustomGrid';
// eslint-disable-next-line import/no-cycle
import SizeSelector from '../../library/component/util/sizeSelector/sizeSelector';
import GsRating from '../../library/component/util/gsrating/GSRating';
// Helper methods
import { addItemTocart, getShoppingCart } from '../../services/helpers/CartItemHelper';
import { store } from '../../services/store/Store';
import { FETCHCARTITEMS } from '../../services/cartncheckout/ActionTypes';
import { FILTER } from '../../services/product/ActionTypes';
// style import
import './productDescription.scss';


const PricePDPView = (props) => {
  const { productPrice: { regularPrice, salePrice }, ratingOpt } = props;

  return (
    <>
      <div className="product-price-wrapper">
        <Typography variant="h5" color="secondary">
          <FormattedMessage id="sale" defaultMessage="sale" />
        </Typography>
        <Typography variant="h4">
          &#36;
          {salePrice}
        </Typography>
        <Typography
          variant="body1"
          className="product-original-price-label"
        >
          <FormattedMessage id="original" defaultMessage="original" />
        </Typography>
        <Typography variant="body1" className="product-original-price">
          &#36;
          {regularPrice}
        </Typography>
      </div>
      <GsRating rating={ratingOpt} />
    </>
  );
};

const ProductQuantityView = (props) => {
  const [productQuantity, setProductQuantity] = useState(1);
  /**
 * product quantity change handler functions
 */
  const handleProductQtyInc = () => setProductQuantity((qty) => qty + 1);
  const handleProductQtyDec = () => setProductQuantity((qty) => (qty > 1 ? (qty - 1) : 1));
  const sharedState = useContext(store);
  const { dispatch } = sharedState;
  /**
   * This block will add the product to the cart and set the shared state
   */
  const handleAddToCart = () => {
    const productObj = {
      ...props.productObj,
      quantity: productQuantity,
      imageSource: 'https://media.kohlsimg.com/is/image/kohls/4206333_Eden_Dot?wid=180&hei=180&op_sharpen=1',
      skuId: 'IXA10',
    };

    addItemTocart(productObj).then(() => {
      getShoppingCart().then((response) => {
        dispatch({ type: FETCHCARTITEMS, response });
      });
    });
  };
  return (
    <>
      <div className="product-quantity-wrapper">
        <Typography className="pdp-quantity-txt">
          <FormattedMessage id="quantity" default="quantity" />
        </Typography>
        <div className="product-quantity-buttons">
          <IconButton aria-label="decrease" size="medium" onClick={handleProductQtyDec}>
            <Remove className={productQuantity === 1 ? 'decrease-product-qty-icon min-amount' : 'decrease-product-qty-icon'} />
          </IconButton>
          <Box className="product-quantity-amount">
            <Typography variant="h6">
              {productQuantity}
            </Typography>
          </Box>
          <IconButton aria-label="increase" size="medium" onClick={handleProductQtyInc}>
            <Add className="increase-product-qty-icon" />
          </IconButton>
        </div>
        <Button
          onClick={handleAddToCart}
          variant="contained"
          className="product-add-to-cart"
          startIcon={<ShoppingCart />}
        >
          <FormattedMessage id="addToCart" default="addToCart" />
        </Button>
      </div>
    </>
  );
};

const GetFavAndCompareView = () => (
  <div className="product-add-to-buttons">
    <Grid container spacing={0} direction="row">
      <Grid item xs={6} className="product-add-to-favorite">
        <div className="add-to-favotite" role="button" tabIndex={0}>
          <FavoriteBorder />
          <Typography>
            <FormattedMessage id="addToFavorite" default="addToFavorite" />
          </Typography>
        </div>
      </Grid>
      <Grid item xs={6} className="product-add-to-compare">
        <div className="add-to-compare" role="button" tabIndex={0}>
          <Compare />
          <Typography>
            <FormattedMessage id="AddToCompare" default="AddToCompare" />
          </Typography>
        </div>
      </Grid>
    </Grid>
  </div>
);

const PDPFilterView = (props) => {
  const {
    swatchImages, sizes, preSelectedColor, preSelectedSize, state, dispatch, setProdutPrice,
    setActiveSKUObject, activeSKUObject,
  } = props;
  const [filters, setActiveFilters] = useState({
    activeSizeOption: state && state.response && activeSKUObject.size ? activeSKUObject.size : '',
    activeColorOption: state && state.response && activeSKUObject.color ? activeSKUObject.color : '',
  });
  /**
   * To handle seleced facet
   * @param {*} item selected facet object
   */
  const handleOptionChange = (item) => {
    state.response.SKUS.forEach((sku) => {
      if (item.facettype === 'color' && sku.color === item.code && activeSKUObject.size === sku.size) {
        // activeSKUObject = sku;
        setActiveFilters({
          filters: {
            activeSizeOption: sku.size,
            activeColorOption: sku.color,
          },
        });
        setActiveSKUObject(sku);
        setProdutPrice(sku.price);
      }
      if (item.facettype === 'size' && sku.size === item.code && activeSKUObject.color === sku.color) {
        // activeSKUObject = sku;
        setActiveFilters({
          filters: {
            activeSizeOption: sku.size,
            activeColorOption: sku.color,
          },
        });
        setProdutPrice(sku.price);
        setActiveSKUObject(sku);
      }
    });
    dispatch({ type: FILTER, response: filters });
  };

  return (
    <>
      <div className="product-color-swatch-wrapper">
        <ColorSwatch
          showActiveColorText="true"
          colorFacets={swatchImages}
          preSelectedColor={preSelectedColor}
          onClick={handleOptionChange}
        />
      </div>
      <div className="product-size-swatch-wrapper">
        <SizeSelector
          showActiveSizeText="true"
          sizeOptions={sizes}
          preSelectedSize={preSelectedSize}
          onClick={handleOptionChange}
        />
      </div>
    </>
  );
};

export default function ProductDescription(props) {
  const {
    title,
    product: {
      price: {
        selected: {
          name,
        },
        options,
      },
      id,
      ratingOpt,
      preSelectedColor,
      preSelectedSize,
      swatchImages,
      sizes,
    },
    state,
    dispatch,
    activeSKUObject,
    setActiveSKUObject,
  } = props;

  const productSalePrice = options.filter((price) => price.name === name)
    .map((price) => price.salePrice).toString();

  const productObj = {
    title,
    price: productSalePrice,
    skuId: id,
  };
  const [productPrice, setProdutPrice] = useState(activeSKUObject.price);
  return (

    <GSMatGridConatiner>
      <GSMatGridItem xsCol={12} smCol={12} mdCol={12} lgCol={12}>
        <div className="product-description-wrapper">
          <div className="pdp-right-panel">
            <PricePDPView
              selectedPrice={name}
              allPrices={options}
              ratingOpt={ratingOpt}
              productPrice={productPrice}
            />
            <PDPFilterView
              preSelectedColor={preSelectedColor}
              preSelectedSize={preSelectedSize}
              swatchImages={swatchImages}
              sizes={sizes}
              state={state}
              dispatch={dispatch}
              setProdutPrice={setProdutPrice}
              activeSKUObject={activeSKUObject}
              setActiveSKUObject={setActiveSKUObject}
            />
            <ProductQuantityView productObj={productObj} />
            <GetFavAndCompareView />
          </div>
        </div>
      </GSMatGridItem>
    </GSMatGridConatiner>
  );
}
