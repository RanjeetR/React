
import React, { useEffect, useState, useReducer } from 'react';
import { withRouter } from 'react-router-dom';
// Material UI components imported  from '@material-ui/core/Grid';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';

// Application components
import Footer from '../common/footer/Footer';
import AppHeader from '../common/header/AppHeader';

// import custom component
import GSBreadcumb from '../../library/component/navigation/breadcrumb/Breadcrumb';
import GsProductTab from '../../library/component/util/gsproducttab/GsProductTab';
import ThirdPartySource from './productThirdParty';
// eslint-disable-next-line import/no-cycle
import ProductDescription from './productDescription';
import ProductCarousal from './productCarousal';
import { get } from '../../services/http/request';
import APP_API from '../../services/http/apiList';
import ProductReducer from '../../services/product/ProductReducer';
import { SETPRODUCT } from '../../services/product/ActionTypes';
// style import
import './product.scss';

export const PdpContext = React.createContext(null);


function ProductPage({ match }) {
  // to show generic loader
  const [isLoading, setIsLoading] = useState(null);
  const [response, setResponse] = useState({});
  const [state, dispatch] = useReducer(ProductReducer, {});
  const [activeSKUObject, setActiveSKUObject] = useState({});
  // Add page effects
  useEffect(() => {
    setIsLoading(true);
    get(APP_API.product,
      { id: match.params.id }).then((data) => {
      setResponse(data);
      setActiveSKUObject(data.SKUS[0]);
      setIsLoading(false);
      dispatch({ type: SETPRODUCT, response: data });
    });
  }, [match.params.id]);
  return (

    <>
      {isLoading === false && (
        <>
          <div className="header-wrapper">
            <AppHeader options={{ headerAPI: APP_API.header }} />
          </div>
          <div className="product-page-wrapper">
            <GSBreadcumb breadcrumbData={response.breadcrumbs} />
            <div className="product-hero-image-wrapper">
              <Grid
                container
                spacing={0}
                direction="row"
                justify="flex-start"
                className="product-hero-wrapper"
              >
                <Grid item xs={12} sm={8}>
                  <div className="product-name-wrapper">
                    <Typography variant="h4" component="h4" className="product-name">{response.product.name}</Typography>
                  </div>
                  <Grid item xs={12} className="product-brand-wrapper">
                    <span>by</span>
                    <span className="product-brand-name">
                      <Typography variant="body2">
                        {response.product.brandName}
                      </Typography>
                    </span>
                  </Grid>
                  {
                  isLoading === false
                  && (
                  <ProductCarousal
                    product={response.product}
                    activeSKUObject={activeSKUObject || response.SKUS[0]}
                  />
                  )
                }
                </Grid>

                <Grid container item justify="center" xs={12} sm={4}>
                  {/* <PdpContext.Provider value={{ PageType: response.page }}> */}
                  <ProductDescription
                    product={response.product}
                    title={response.title}
                    skus={response.SKUS}
                    state={state}
                    dispatch={dispatch}
                    activeSKUObject={activeSKUObject || response.SKUS[0]}
                    setActiveSKUObject={setActiveSKUObject}
                  />
                  {/* </PdpContext.Provider> */}
                </Grid>
              </Grid>
            </div>
            <Grid item lg={6}>
              <GsProductTab availableAccordions={response.product.availableAccordions} />
            </Grid>
            <Grid item lg={6} />
            <ThirdPartySource response={response} />
          </div>
          <div className="footer-wrapper">
            <Footer options={{ footerAPI: APP_API.footer_data }} />
          </div>
        </>
      )}
    </>
  );
}
export default withRouter(ProductPage);
