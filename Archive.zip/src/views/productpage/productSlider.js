/* eslint-disable react/prop-types */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* This component is to replicate the Like it and simliar product section on Kohls product page.
This component is just for demo purpose. In reality this page comes from
third party.
*/

import React from 'react';
import Slider from 'react-slick';

// Material UI - Card Component
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardMedia from '@material-ui/core/CardMedia';
import CardContent from '@material-ui/core/CardContent';


const useStyles = makeStyles(() => ({
  root: {
    maxWidth: 200,
    textAlign: 'center',
    boxShadow: 'none',
  },
  media: {
    height: 200,
  },
}));

export default function MultipleItems(props) {
  const classes = useStyles();
  const { productLabel, productData } = props;
  const productPageCarouselSettings = {
    dots: false,
    infinite: true,
    slidesToShow: 6,
    slidesToScroll: 1,
    arrows: true,
    adaptiveHeight: true,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 5,
          slidesToScroll: 1,
          infinite: true,
          dots: false,
          arrows: true,
        },
      },
      {
        breakpoint: 900,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 1,
          infinite: true,
          arrows: true,
          dots: false,
        },
      },
      {
        breakpoint: 660,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: true,
          arrows: true,
          dots: false,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
          dots: true,
          arrows: false,
        },
      },
    ],
  };

  return (
    <>
      <div>
        <section>
          <Typography variant="h6" component="h6" align="center">
            {productLabel}
          </Typography>
          <div className="similar-product-wrapper">
            {/* eslint-disable-next-line react/jsx-props-no-spreading */}
            <Slider {...productPageCarouselSettings}>
              {productData.map((elem) => {
                return (
                  <Card className={classes.root} key={`product-${elem.id}`}>
                    <CardMedia
                      className={classes.media}
                      image={elem.url}
                      title={elem.name}
                    />
                    <CardContent>
                      <Typography
                        variant="body2"
                        color="textSecondary"
                        component="p"
                      >
                        {elem.productType}
                        {elem.basePrice}
                        {elem.description}
                      </Typography>
                    </CardContent>
                  </Card>
                );
              })}
            </Slider>
          </div>
        </section>
      </div>
    </>
  );
}
