/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable react/jsx-filename-extension */
import React from 'react';

// Material UI components imported  from '@material-ui/core/Grid';
import Grid from '@material-ui/core/Grid';

import StyleItYourWay from './StyleItProduct';
import MultipleItems from './productSlider';

// style import
// import './product.scss';

import './productThirdParty.scss';
import staticContent from '../../localisation/en/staticContent';

export default function ThirdPartySource(props) {
  const {
    response: { styleItYourWay, similarProducts, LikeProducts },
  } = props;

  return (
    <div className="third-party-component-wrapper">
      <Grid item lg={12}>
        <div className="styleIt-section">
          <StyleItYourWay productData={styleItYourWay} />
        </div>
      </Grid>
      <Grid item lg={12}>
        <div className="similarProduct-section">
          <div>
            <MultipleItems
              productData={similarProducts}
              productLabel={staticContent.alsoViewdText}
            />
          </div>
        </div>
      </Grid>
      <Grid item lg={12}>
        <div className="likeProduct-section">
          <div>
            <MultipleItems
              productData={LikeProducts}
              productLabel={staticContent.inspiredByYourRecentlyViewed}
            />
          </div>
        </div>
      </Grid>
    </div>
  );
}
