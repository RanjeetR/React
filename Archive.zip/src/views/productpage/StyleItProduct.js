/* eslint-disable react/prop-types */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* This component is to replicate the style It section on Kohls product page.
    This component is just for demo purpose. In reality this page comes from
    third party.
    This is temporary file and ittt will be deleted.
    This file consist of reducdant implmentation of carousal, Hence Need to merge
    With the productSlider.js
*/

import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick-theme.css';
import Typography from '@material-ui/core/Typography';
import Card from '@material-ui/core/Card';
import CardMedia from '@material-ui/core/CardMedia';
import { makeStyles } from '@material-ui/core/styles';
import staticContent from '../../localisation/en/staticContent';


const useStyles = makeStyles(() => ({
  root: {
    maxWidth: 400,
    textAlign: 'center',
    boxShadow: 'none',
  },
  media: {
    height: 400,
  },
}));

export default function StyleItYourWay(props) {
  const classes = useStyles();
  const { productData } = props;

  const productPageCarouselSettings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    arrows: true,
    adaptiveHeight: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: true,
          dots: false,
          arrows: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
          arrows: false,
          dots: true,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
          dots: true,
          arrows: false,
        },
      },
    ],
  };

  return (
    <>
      <div className="styleIt-wrapper">
        <Typography variant="h5" component="h5" align="center">
          {staticContent.styleItYourWay}
        </Typography>
        {/* eslint-disable-next-line react/self-closing-comp */}
        <div className="horizontal-line"></div>
        <section className="styleIt-slider-wrapper">
          {/* eslint-disable-next-line react/jsx-props-no-spreading */}
          <Slider {...productPageCarouselSettings}>
            {productData.map((elem) => {
              return (
                <Card className={classes.root} key={`product - ${elem.id}`}>
                  <CardMedia
                    className={classes.media}
                    image={elem.url}
                    title={elem.name}
                  />
                </Card>
              );
            })}
          </Slider>
        </section>
      </div>
    </>
  );
}
