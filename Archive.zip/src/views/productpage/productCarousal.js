/* eslint-disable jsx-a11y/control-has-associated-label */

import React from 'react';
// import custom component
import GSPdpCarousel from '../../library/component/util/gspdpcarousel/gspdpcarousel';
// import styiling.
import './productCarousal.scss';

export default function ProductCarousal(props) {
  const {
    product: {
      images: {
        options,
      },
    },
    activeSKUObject,
  } = props;

  return (
    <>
      <div className="pdp-left-panel">
        <section className="product-carousel-wrapper">
          <GSPdpCarousel
            selecteditem={activeSKUObject.color !== null ? activeSKUObject.color : ''}
            allitems={options}
          />
          <div id="slide-control" />
        </section>
      </div>
    </>
  );
}
