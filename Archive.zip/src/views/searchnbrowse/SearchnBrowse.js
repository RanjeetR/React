// React imports
import React from 'react';
//  Application components
import Footer from '../common/footer/Footer';
import AppHeader from '../common/header/AppHeader';
import ProductListing from './ProductListing';
// API Methods
import APP_API from '../../services/http/apiList';

export default function SearchnBrowse() {
  return (
    <>
      <section className="header-wrapper">
        <AppHeader options={{ headerAPI: APP_API.header }} />
      </section>
      <section className="product-section">
        <ProductListing options={{ SearchnBrowseAPI: APP_API.search_browse }} />
      </section>
      <section className="footer-wrapper">
        <Footer options={{ footerAPI: APP_API.footer_data }} />
      </section>
    </>
  );
}
