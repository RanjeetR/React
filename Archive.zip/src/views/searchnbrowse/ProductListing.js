/* eslint-disable no-unused-vars */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React, { useState, useEffect, useMemo } from 'react';
import { withRouter } from 'react-router-dom';
import { uid } from 'react-uid';
//  Library components
import ProductMatrix from '../../library/component/layout/productmatrix/ProductMatrix';
import StorePagination from '../../library/component/navigation/storepagination/StorePagination';
import GSCard from '../../library/component/layout/gscard/GsCard';
import { GSMatGridConatiner, GSMatGridItem } from '../../library/component/layout/gsgrid/CustomGrid';

import { queryStringToJSONArray, getParsedUrlForFilterHandle } from '../../services/helpers/SearchAndBrowseHelper';
//  Application components
import SearchHeader from '../common/searchheader/SearchHeader';
import CustomFilter from '../common/filters/CustomFilter';
// import state management hook
import { get } from '../../services/http/request';
// style import
import './snb.scss';

function ProductListing({ options, location, history }) {
  const { SearchnBrowseAPI } = options;
  // get initial data and setter methods
  const [showClearFilters, setShowClearFilters] = useState(false);
  const [selectedFilters, setSelectedFilters] = useState([]);

  // to show generic loader
  const [isLoading, setIsLoading] = useState(false);
  const [closeMobilefilters, setCloseMobilefilters] = useState(false);
  const [page, setPage] = React.useState(1);
  const [sortBy, setSortBy] = React.useState(null);
  const [queryParams, setQueryParams] = React.useState('');
  // To fetch json data
  const [response, setResponse] = useState();
  const [renderItems, setRenderItems] = useState(false);
  const [filters, setFilters] = useState([]);
  /**
   * To set the current states and flags for loading
   */
  const setResponseForListing = (data) => {
    setIsLoading(false);
    setResponse(data);
    setRenderItems(true);
  };
  // Add page effects
  useEffect(() => {
    setIsLoading(true);
    let filterRequest = [];
    let queryString = queryParams;
    // to filter request for service call
    filterRequest = queryStringToJSONArray(location.search);
    if (queryString === '') {
      queryString = location.search;
    }
    // queryString also need to be send in get api params
    get(`${SearchnBrowseAPI}`, {
      filters: filterRequest,
      pageNo: page,
    })
      .then((data) => {
        setResponseForListing(data);
        setSelectedFilters(filterRequest);
        if (filters.length === 0) setFilters(data.filters);
      });
  }, [page, queryParams, SearchnBrowseAPI, location]);
  // to set filters data and prevent re-rendering
  const recentFilters = useMemo(() => filters, [filters]);
  /**
   *  To handle facets changes
   * @param {*} facet as selected facet object
   */
  const handleFilterChange = (facet) => {
    // to modify selected filters object
    selectedFilters.forEach((item, index) => {
      if (item && item.facettype === facet.facettype && facet.code != null) {
        selectedFilters[index].code = facet.code;
        selectedFilters[index].facettype = facet.facettype;
        setSelectedFilters(selectedFilters);
      }
    });
    const searchUrl = `/search${getParsedUrlForFilterHandle(location.search, facet)}`;
    setQueryParams(searchUrl);
    history.push(searchUrl);
    if (searchUrl === '/search?') setShowClearFilters(false);
    else setShowClearFilters(true);
  };
  /**
   * To clear selected filters
   */
  const handleClearFilter = () => {
    // clear mobile filter view if it is visible
    if (closeMobilefilters === true) {
      setCloseMobilefilters(false);
    }
    history.push('/search');
    setShowClearFilters(false);
    setSelectedFilters([]);
    setFilters([]);
    setQueryParams('');
  };
  // products to be rendered
  const products = renderItems === true
    && response !== null
    && response.data
    && response.data.items.length
    && response.data.items.map((product, i) => {
      const classes = i % 2 === 0
        ? 'no-box-shadow-effect no-border-effect product-card-even'
        : 'no-box-shadow-effect no-border-effect product-card-odd';
      return (
        <GSMatGridItem xsCol={6} smCol={6} mdCol={4} lgCol={3} xlCol={2} key={uid(product)}>
          <a href={product.productUrl}>
            <GSCard
              key={product.url}
              className={classes}
              productPrice={product.price}
              productUrl={product.url}
              action={false}
              detail="Minerva LumaTech™ V-Tee"
              blendMode
              backgroundImage
            />
          </a>
        </GSMatGridItem>
      );
    });
  const sortProductsHandler = (event) => {
    const val = event.target.value;
    if (typeof val !== 'undefined') {
      const obj = {
        facettype: 'sort',
        code: val,
      };
      setSortBy(val);
      handleFilterChange(obj);
    }
  };
  /**
   *  to Handle page change
   * @param {*} event
   * @param {*} pageNo navigate to page number pageNo
   */
  const handlePageChange = (event, pageNo) => {
  // service call will go here
  // to filter request for service call
    const filterRequest = selectedFilters.filter((item) => item.code !== null);
    get(SearchnBrowseAPI, {
      filters: filterRequest,
      pageNo,
    })
      .then((data) => {
        setResponseForListing(data);
      });
  };
  return (
    <div>
      {' '}
      { (renderItems === true) && response !== null && (
      <section className="product-listing">
        <SearchHeader
          snbData={response.metadata}
          sortProductsHandler={sortProductsHandler}
          setCloseMobilefilters={setCloseMobilefilters}
        />
        {/* Filter section start */}
        <GSMatGridConatiner spacing={0} align="center">
          <CustomFilter
            filters={recentFilters}
            handleFilterChange={handleFilterChange}
            showClearFilters={showClearFilters}
            handleClearFilter={handleClearFilter}
            setCloseMobilefilters={setCloseMobilefilters}
            closeMobilefilters={closeMobilefilters}
          />
          {/* Filter section end */}
          {/* Products Grid */}
          <ProductMatrix products={products} isLoading={isLoading} />
        </GSMatGridConatiner>
        { products.length
          ? (
            <StorePagination
              page={page}
              handlePageChange={handlePageChange}
              count={5}
            />
          )
          : ''}
      </section>
      )}
    </div>
  );
}
export default withRouter(ProductListing);
