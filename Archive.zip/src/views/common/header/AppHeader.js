
/* eslint-disable no-shadow */
import React, { useState, useEffect, useContext } from 'react';
import { useHistory } from 'react-router-dom';
// MUI components
import useMediaQuery from '@material-ui/core/useMediaQuery';
import FavoriteBorderIcon from '@material-ui/icons/FavoriteBorder';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import LocationOnOutlinedIcon from '@material-ui/icons/LocationOnOutlined';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
// import ArrowForwardSharpIcon from '@material-ui/icons/ArrowForwardSharp';
import Badge from '@material-ui/core/Badge';
import SearchIcon from '@material-ui/icons/Search';
import CloseIcon from '@material-ui/icons/Close';
import Hidden from '@material-ui/core/Hidden';
// Library Component
import AppLogo from '../../../library/component/util/applogo/AppLogo';
import MenuDropDowns from '../../../library/component/navigation/dropdowns/MenuDropDowns';
import SearchBox from '../../../library/component/inputs/searcbox/SearchBox';
import VoiceSearch from '../../../library/component/inputs/voicesearch/VoiceSearch';
import CartOverViewDrawer from '../cartoverview/CartOverViewDrawer';
// API and helper methods
import { get } from '../../../services/http/request';
import { getShoppingCart } from '../../../services/helpers/CartItemHelper';
// store
import { store } from '../../../services/store/Store';
import { FETCHCARTITEMS } from '../../../services/cartncheckout/ActionTypes';
// constant imports
import staticContents from '../../../localisation/en/staticContent';
// scss file
import './AppHeader.scss';


export default function AppHeader({ options }) {
  const { headerAPI } = options;
  const sharedState = useContext(store);
  const { state, dispatch } = sharedState;
  const [headerData, setHeaderResponse] = useState(null);
  const [headerDataLoaded, setDataLoaded] = useState(false);
  const history = useHistory();
  /** Set intian state values */
  const [showMobileSearchBox, setShowMobileSearchBox] = useState(false);
  const [showDrawer, setShowDrawer] = useState(false);

  /** Hook to listen screen dimension */
  const enableMobileView = useMediaQuery('(max-width:768px)');
  /** Handle mobile search icon click event */
  function handleMobileSearchIconClick() {
    setShowMobileSearchBox(!showMobileSearchBox);
  }

  /** Add and remove event listeners & Call required methods */
  useEffect(() => {
    get(headerAPI)
      .then((response) => {
        setHeaderResponse(response);
        setDataLoaded(true);
      }).catch((error) => {
        console.log('error loading header data', error);
      });
    getShoppingCart().then((response) => {
      dispatch({ type: FETCHCARTITEMS, response });
    });
  }, [headerAPI, dispatch]);

  /** Find display mode */
  const mobileSearchBoxProp = showMobileSearchBox ? 'flex' : 'none';
  const displaySearchBox = !enableMobileView ? 'flex' : mobileSearchBoxProp;
  const [searchText, setSearchText] = useState('');
  let dText = '';
  const handleCartDrawser = () => {
    // eslint-disable-next-line no-unused-expressions
    showDrawer ? setShowDrawer(false) : setShowDrawer(true);
  };
  const getSearchText = (text) => {
    dText = text;
    setSearchText(text);
  };
  const listeningEnded = () => {
    history.push(`/search/${dText}`);
  };
  return (
    <>
      {headerDataLoaded && (
      <header className="header-container">
        <div className="logo-category-container">
          <MenuDropDowns
            heading={staticContents.headerMenuLabel}
            categories={headerData.categories}
            width={staticContents.headerMenuWidth}
            subHeading={staticContents.subTitle}
          />
          <a href="/home">
            <AppLogo
              logo={staticContents.logoImgSrc}
              altText={staticContents.logoAltText}
              heightForDesktop={staticContents.logoHeightDesktop}
              heightForMobile={staticContents.logoHeightMobile}
            />
          </a>
          <div className="mobile-search-and-shoppinCart-icon">
            {!showMobileSearchBox
               && <SearchIcon onClick={handleMobileSearchIconClick} style={{ paddingRight: 13 }} />}
            {showMobileSearchBox
                && <CloseIcon onClick={handleMobileSearchIconClick} style={{ paddingRight: 13 }} />}
            <a href="/checkout">
              <Badge badgeContent={state && state.response && state.response.length} color="primary">
                <ShoppingCartIcon />
              </Badge>
            </a>
          </div>
        </div>

        <div className="search-container" style={{ display: displaySearchBox }}>
          <SearchBox recentSearchItems={headerData.recentSearchItems} placeholder="Search" searchText={searchText} />
          <section className="voice-search">
            <VoiceSearch
              getSearchText={getSearchText}
              continuousResult
              endListening={listeningEnded}
            />
          </section>
        </div>
        <section className="header-icon-container">
          <div className="header-icon"><FavoriteBorderIcon /></div>
          <div className="header-icon">
            <Hidden only={['xs', 'sm']}>
              {/* <ShoppingCartIcon onClick={handleCartDrawser} /> */}
              <Badge onClick={handleCartDrawser} badgeContent={state && state.response && state.response.length} color="primary">
                <ShoppingCartIcon />
              </Badge>
            </Hidden>
            <Hidden only={['md', 'lg']}>
              <a href="/checkout">
                <Badge badgeContent={state && state.response && state.response.length} color="primary">
                  <ShoppingCartIcon />
                </Badge>
              </a>
            </Hidden>
          </div>
          <div className="header-icon"><AccountCircleIcon /></div>
          <div className="header-icon"><LocationOnOutlinedIcon /></div>
        </section>

      </header>
      )}
      <Hidden only={['xs', 'sm']}>
        <section className="cart-overview">
          <CartOverViewDrawer options={{ showDrawer, cartItems: state.response }} />
        </section>
      </Hidden>
    </>
  );
}
