
import React from 'react';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import FormControl from '@material-ui/core/FormControl';
import Button from '@material-ui/core/Button';
import Hidden from '@material-ui/core/Hidden';
import Typography from '@material-ui/core/Typography';
import GSBreadcumb from '../../../library/component/navigation/breadcrumb/Breadcrumb';
import staticContent from '../../../localisation/en/staticContent';
import { GSMatGridConatiner, GSMatGridItem } from '../../../library/component/layout/gsgrid/CustomGrid';

export default function SearchHeader({ snbData, sortProductsHandler, setCloseMobilefilters }) {
  const [sortBy, setSortBy] = React.useState('');

  const sortProductsHandlr = (event) => {
    if (typeof event.target.value !== 'undefined') {
      setSortBy(event.target.value);
      sortProductsHandler(event);
    }
  };
  return (
    <div className="sub-header">
      <GSMatGridConatiner>
        <GSMatGridItem lgCol={12} mdCol={12} smCol={6} xsCol={6}>
          {snbData && snbData.breadcrumbs.length ? <GSBreadcumb breadcrumbData={snbData.breadcrumbs} /> : ''}
        </GSMatGridItem>
        <GSMatGridItem xlCol={12} lgCol={12} mdCol={12} smCol={6} xsCol={6}>
          <Hidden only={['sm', 'md', 'lg', 'xl']}>
            <Button className="custom-filter-btn" onClick={() => setCloseMobilefilters(true)}>
              {staticContent.filterText}
            </Button>
          </Hidden>
        </GSMatGridItem>
        <GSMatGridItem xlCol={12} lgCol={12} mdCol={12} smCol={12} xsCol={12}>
          <div className="sort-options-container">
            <div>
              {' '}
              <Typography variant="h4" className="catageory-name">Tops</Typography>
              {' '}
            </div>
            <div>
              <FormControl>
                <InputLabel id="sort-select-label">{staticContent.sortByLabel}</InputLabel>
                <Select
                  labelId="sort-select-label"
                  displayEmpty
                  onClick={(e) => sortProductsHandlr(e)}
                  inputProps={{
                    id: 'sort-options',
                  }}
                  value={sortBy}
                  className="sort-options"
                >
                  {snbData && snbData.sortOptions
                    && snbData.sortOptions.map((item) => (
                      <MenuItem key={item.code} value={item.code}>{item.name}</MenuItem>
                    ))}
                </Select>
              </FormControl>
            </div>

          </div>
        </GSMatGridItem>
      </GSMatGridConatiner>
    </div>
  );
}
