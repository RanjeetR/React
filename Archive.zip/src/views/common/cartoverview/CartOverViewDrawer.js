/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable react/jsx-no-bind */
/* eslint-disable react/jsx-indent */
/* eslint-disable jsx-a11y/label-has-associated-control */
/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable react/prop-types */
import React, { useContext } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import Box from '@material-ui/core/Box';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import { uid } from 'react-uid';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import AddIcon from '@material-ui/icons/Add';
import RemoveIcon from '@material-ui/icons/Remove';
import staticContent from '../../../localisation/en/staticContent';
import { CardFlipper, CardFront, CardBack } from '../../../library/component/util/cardflipper';
import { modifyCart, cartTotalCalculator } from '../../../services/helpers/CartItemHelper';
import { store } from '../../../services/store/Store';
import { FETCHCARTITEMS } from '../../../services/cartncheckout/ActionTypes';
import './cartoverview.scss';

const cartDrawerStyles = makeStyles(() => ({
  icon: {
    verticalAlign: 'bottom',
    height: 20,
    width: 20,
  },
  details: {
    alignItems: 'center',
    boxShadow: '0 0 4px rgba(0,0,0,.35)',
    background: 'none repeat scroll 0 0 #f0f0f0',
  },
  columnParent: {
    display: 'flex',
    width: '62%',
    margin: '0 auto',
    justifyContent: 'space-evenly',
  },
  cartColumn: {
    flexBasis: '60%',
    background: 'white',
    display: 'flex',
    flexWrap: 'nowrap',
    overflowX: 'auto',
  },
  priceColumn: {
    flexBasis: '30%',
  },

  images: {
    height: '60px',
    overflow: 'hidden',
    transition: 'all .2s ease-in-out',
  },

  text: {
    background: '#FFF',
    padding: '6px',
    height: '30px',
    textAlign: 'center',
    overflow: 'hidden',
    textOverflow: 'ellipsis',


  },
  cartIcon: {
    background: 'white',
    marginLeft: '1%',
    marginRight: '1%',
  },
}));

export default function CartOverViewDrawer({ options }) {
  const classes = cartDrawerStyles();

  const sharedState = useContext(store);
  const { dispatch } = sharedState;
  const { showDrawer, cartItems } = options;
  const flipperConfig = {
    width: '90px',
    height: '110px',
  };
  const changeQuantity = (type, item) => {
    if (type === 'add') {
      item.quantity++;
    } else if (item.quantity > 1) {
      item.quantity--;
    }

    modifyCart(item, cartItems, type).then((data) => {
      dispatch({ type: FETCHCARTITEMS, response: data });
    });
  };
  const getTotalPrice = () => <strong>{cartTotalCalculator(cartItems)}</strong>;
  return (
    <div className={classes.root}>
      <ExpansionPanel expanded={showDrawer}>
        <div />
        <ExpansionPanelDetails className={classes.details}>
          <div className={classes.columnParent}>
            <div className={classes.cartColumn}>
                {cartItems && cartItems.length
                  ? cartItems.map((item, index) => (
                  <CardFlipper key={uid(index)} options={flipperConfig}>
                    <CardFront>
                      <div className={classes.images}>
                        <img src={item.imageSource} width="100%" />
                      </div>
                      <div className={classes.text}>
                        {item.title}
                      </div>
                    </CardFront>
                    <CardBack>
                      <div className="cart-wrapper-size">
                       {staticContent.currenySign}
                        {item.price}
                      </div>
                      <div className="cart-wrapper">
                        <div><AddIcon onClick={changeQuantity.bind(null, 'add', item)} /></div>
                        <div><label>{ item.quantity }</label></div>
                        <div><RemoveIcon onClick={changeQuantity.bind(null, 'remove', item)} /></div>
                      </div>
                      <div className="remove-link">
                        <label onClick={changeQuantity.bind(null, 'delete', item)}> remove item</label>
                      </div>
                    </CardBack>
                  </CardFlipper>
                  ))

                  : '' }

            </div>
            <div className={classes.cartIcon}>
              <Box p={2} className="itemBox">
                <a href="/checkout">
                <ShoppingCartIcon />
                 <label>view cart</label>
                </a>
              </Box>
            </div>

            <div className={classes.priceColumn}>
              <Typography variant="body1">
                Order Summary
              </Typography>
              <Typography variant="body2"> Price:- $110</Typography>
              <Typography variant="body2"> Discount:- $55</Typography>
              <Typography variant="body2"> Estimated tax:- $5 </Typography>
              <Divider />
              <Typography variant="body1">
Total:-
{' '}
{staticContent.currenySign}
              {getTotalPrice()}
              </Typography>


            </div>
          </div>
        </ExpansionPanelDetails>
      </ExpansionPanel>
    </div>
  );
}
