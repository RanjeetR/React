/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable react/prop-types */
/* eslint-disable react/destructuring-assignment */
import React, { useState } from 'react';
import {
  Close, Cancel, Add as AddIcon, Remove as RemoveIcon,
  ExpandMore,
} from '@material-ui/icons';
import {
  ExpansionPanel, ExpansionPanelDetails, ExpansionPanelSummary, Hidden, Button, Typography,
} from '@material-ui/core';
import { uid } from 'react-uid';
import GSColorSwatch from '../../../library/component/util/colorSwatch/ColorSwatch';
import GSSizeSelector from '../../../library/component/util/sizeSelector/sizeSelector';
import GSPriceSelector from '../../../library/component/util/priceSelector/priceSelector';
import { GSMatGridItem } from '../../../library/component/layout/gsgrid/CustomGrid';

import constant from '../../../config/env_dev.constant';
import staticContent from '../../../localisation/en/staticContent';

import './filter.scss';


export default function CustomFilter(props) {
  /**
   *  Clear filter option to clear selected filters.
   */
  const filter = props.showClearFilters === true ? (
    <span className="snb-clear-filter" onClick={props.handleClearFilter} role="button" tabIndex={0}>
      <Cancel />
      {' '}
      {staticContent.removeFilterText}
    </span>
  ) : null;

  const [expanded, setExpanded] = useState(true);

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  const toggleIcon = (toggle) => (toggle ? <RemoveIcon /> : <AddIcon />);

  function getMobileView() {
    return (
      <>
        {props.closeMobilefilters === true
          ? (
            <div className="sm-view">
              <Close onClick={() => props.setCloseMobilefilters(false)} className="filter-close-icon" />
              <div className="snb-filter-text-wrapper">
                <span className="snb-filter">{staticContent.filterText}</span>
                {filter}
              </div>
              { props.filters && props.filters.length && props.filters.map((filterItem) => (
                <div>
                  {filterItem.filterComponentType === 'roundedButtons'}
                  <div>
                    {(function () {
                      switch (filterItem.filterComponentType) {
                        case 'roundedButtons':
                          return (
                            <Hidden only={['sm', 'md', 'lg', 'xl']}>
                              <div className="snb-color-filter">
                                <ExpansionPanel
                                  className="filter-expansion-panel"
                                  defaultExpanded={constant.enableDefaultExpandedFilterView}
                                  // expanded={expanded === filterItem.filterName}
                                  onChange={handleChange(filterItem.filterName)}
                                >
                                  <ExpansionPanelSummary expandIcon={<ExpandMore />}>
                                    <Typography>{filterItem.filterName}</Typography>
                                  </ExpansionPanelSummary>
                                  <ExpansionPanelDetails>
                                    <GSColorSwatch className="color-filter" onClick={props.handleFilterChange} showActiveColorText="false" colorFacets={filterItem.filterOptions} />
                                  </ExpansionPanelDetails>
                                </ExpansionPanel>
                              </div>
                            </Hidden>
                          );
                        case 'checkBoxes':
                          return (
                            <Hidden only={['sm', 'md', 'lg', 'xl']}>
                              <div className="snb-size-filter">
                                <ExpansionPanel
                                  className="filter-expansion-panel"
                                  defaultExpanded={constant.enableDefaultExpandedFilterView}
                                  // expanded={expanded === filterItem.filterName}
                                  onChange={handleChange(filterItem.filterName)}
                                >
                                  <ExpansionPanelSummary expandIcon={<ExpandMore />} >
                                    <Typography>{filterItem.filterName}</Typography>
                                  </ExpansionPanelSummary>
                                  <ExpansionPanelDetails>
                                    <GSSizeSelector className="size-filter" onClick={props.handleFilterChange} showActiveSizeText="false" sizeOptions={filterItem.filterOptions} />
                                  </ExpansionPanelDetails>
                                </ExpansionPanel>
                              </div>
                            </Hidden>
                          );
                        case 'reactangleBoxes':
                          return (
                            <Hidden only={['sm', 'md', 'lg', 'xl']}>
                              <div className="snb-price-filter">
                                <ExpansionPanel
                                  className="filter-expansion-panel"
                                  defaultExpanded={constant.enableDefaultExpandedFilterView}
                                  // expanded={expanded === filterItem.filterName}
                                  onChange={handleChange(filterItem.filterName)}
                                >
                                  <ExpansionPanelSummary expandIcon={<ExpandMore />} >
                                    <Typography>{filterItem.filterName}</Typography>
                                  </ExpansionPanelSummary>
                                  <ExpansionPanelDetails>
                                    <GSPriceSelector onClick={props.handleFilterChange} showActivePriceText="false" priceOptions={filterItem.filterOptions} />
                                  </ExpansionPanelDetails>
                                </ExpansionPanel>
                              </div>
                            </Hidden>
                          );
                        default:
                          return '';
                      }
                    }())}
                  </div>
                </div>
              ))}
              <div>
                <Button onClick={() => props.setCloseMobilefilters(false)} className="sm-filter-btn custom-filter-btn" id="sm-filter">
                  {staticContent.applyFilterButton}
                </Button>
              </div>
            </div>
          )
          : ''}
      </>
    );
  }
  function getLargeView() {
    return (
      <div className="filter-section">
        <Hidden xsDown>
          <div className="snb-filter-text-wrapper">
            <span className="snb-filter">{staticContent.filterText}</span>
            {filter}
          </div>
        </Hidden>
        <div>
          {props.filters.map((filterItem) => (
            <div key={uid(filterItem)}>
              {filterItem.filterComponentType === 'roundedButtons'}
              <div>
                {(function () {
                  switch (filterItem.filterComponentType) {
                    case 'roundedButtons':
                      return (
                        <Hidden xsDown>
                          <div className="snb-color-filter">
                            <ExpansionPanel
                              className="filter-expansion-panel"
                              defaultExpanded={constant.enableDefaultExpandedFilterView}
                              onChange={handleChange(filterItem.filterName)}
                            >
                              <ExpansionPanelSummary expandIcon={<ExpandMore />}>
                                <Typography>{filterItem.filterName}</Typography>
                              </ExpansionPanelSummary>
                              <ExpansionPanelDetails>
                                <GSColorSwatch className="color-filter" onClick={props.handleFilterChange} showActiveColorText="false" colorFacets={filterItem.filterOptions} />
                              </ExpansionPanelDetails>
                            </ExpansionPanel>
                          </div>
                        </Hidden>
                      );
                    case 'checkBoxes':
                      return (
                        <Hidden xsDown>
                          <div className="snb-size-filter">
                            <ExpansionPanel
                              defaultExpanded={constant.enableDefaultExpandedFilterView}
                              className="filter-expansion-panel"
                              // expanded={expanded === filterItem.filterName}
                              onChange={handleChange(filterItem.filterName)}
                            >
                              <ExpansionPanelSummary expandIcon={<ExpandMore />}>
                                <Typography>{filterItem.filterName}</Typography>
                              </ExpansionPanelSummary>
                              <ExpansionPanelDetails>
                                <GSSizeSelector className="size-filter" onClick={props.handleFilterChange} showActiveSizeText="false" sizeOptions={filterItem.filterOptions} />
                              </ExpansionPanelDetails>
                            </ExpansionPanel>
                          </div>
                        </Hidden>
                      );
                    case 'reactangleBoxes':
                      return (
                        <Hidden xsDown>
                          <div className="snb-price-filter">
                            <ExpansionPanel
                              defaultExpanded={constant.enableDefaultExpandedFilterView}
                              className="filter-expansion-panel"
                              // expanded={expanded === filterItem.filterName}
                              onChange={handleChange(filterItem.filterName)}
                            >
                              <ExpansionPanelSummary expandIcon={<ExpandMore />}>
                                <Typography>{filterItem.filterName}</Typography>
                              </ExpansionPanelSummary>
                              <ExpansionPanelDetails>
                                <GSPriceSelector onClick={props.handleFilterChange} showActivePriceText="false" priceOptions={filterItem.filterOptions} />
                              </ExpansionPanelDetails>
                            </ExpansionPanel>
                          </div>
                        </Hidden>
                      );
                    default:
                      return '';
                  }
                }())}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  return (
    <GSMatGridItem xsCol={10} smCol={3} mdCol={2} lgCol={2}>
      {/* Filter large view start */}
      {getLargeView(props)}
      {/* Filter large view end */}
      {/* Filter mobile view start */}
      {getMobileView(props)}
      {/* Filter mobile view end */}
    </GSMatGridItem>
  );
}
