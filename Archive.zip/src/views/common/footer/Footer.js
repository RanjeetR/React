/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState, useEffect } from 'react';
import './Footer.scss';
import AppFooter from '../../../library/component/surface/footer/AppFooter';
import { get } from '../../../services/http/request';

import staticContent from '../../../localisation/en/staticContent';

export default function Footer({ options }) {
  const { footerAPI } = options;
  const [footerLink, setFooterLink] = useState([]);
  const [loadFooter, setLoadFooter] = useState(false);
  useEffect(() => {
    get(footerAPI)
      .then((response) => {
        if (response && response.sections.length) {
          setFooterLink(response);
          setLoadFooter(true);
        }
      }).catch((error) => {
        console.log('error loading footer data', error);
      });
  }, [footerAPI]);

  return (
    <>
      <section className="pre-footer-section">
        <div className="footer-text-wrapper"><h3 className="footer-text">{staticContent.preFooterText}</h3></div>
        <div className="footer-btn-wrapper"><button type="button" className="footer-btn">{staticContent.preFooterButton}</button></div>
      </section>
      {loadFooter ? <AppFooter options={footerLink} /> : ''}

    </>
  );
}
