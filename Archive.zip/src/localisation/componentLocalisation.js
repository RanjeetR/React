/* eslint-disable import/prefer-default-export */

export const hi = {
  props: {
    MuiBreadcrumbs: {
      expandtext: 'रास्ता दिखायें',
    },
    MuiTablePagination: {
      backIconButtonText: 'पिछला पृष्ठ',
      labelRowsPerPage: 'पंक्तियाँ प्रति पृष्ठ:',
      labelDisplayedRows: ({ from, to, count }) => `${from}-${to === -1 ? count : to} कुल ${count} में`,
      nextIconButtonText: 'अगला पृष्ठ',
    },
    MuiRating: {
      getLabelText: (value) => `${value} तार${value !== 1 ? 'े' : 'ा'}`,
      emptyLabelText: 'रिक्त',
    },
    MuiAutocomplete: {
      clearText: 'हटायें',
      closeText: 'बंद करें',
      loadingText: 'लोड हो रहा है…',
      noOptionsText: 'कोई विकल्प नहीं',
      openText: 'खोलें',
    },
    MuiAlert: {
      closeText: 'बंद करें',
    },
    MuiPagination: {
      'aria-label': 'पृस्ठानुसार संचालन',
      getItemAriaLabel: (type, page, selected) => {
        if (type === 'page') {
          return `पृष्ठ ${page} ${selected ? '' : ' पर जाएँ'}`;
        }
        if (type === 'first') {
          return 'पहले पृष्ठ पर जाएँ';
        }
        if (type === 'last') {
          return 'अंतिम पृष्ठ पर जाएँ';
        }
        if (type === 'next') {
          return 'अगले पृष्ठ पर जाएँ';
        }
        if (type === 'previous') {
          return 'पिछले पृष्ठ पर जाएँ';
        }
        return undefined;
      },
    },
  },
};


export const en = {
  props: {
    MuiBreadcrumbs: {
      expandtext: 'Show path',
    },
    MuiTablePagination: {
      backIconButtonText: 'Previous page',
      labelRowsPerPage: 'Rows per page:',
      labelDisplayedRows: ({ from, to, count }) => `${from}-${to} of ${count !== -1 ? count : `more than ${to}`}`,
      nextIconButtonText: 'Next page',
    },
    MuiRating: {
      getLabelText: (value) => `${value} Star${value !== 1 ? 's' : ''}`,
      emptyLabelText: 'Empty',
    },
    MuiAutocomplete: {
      clearText: 'Clear',
      closeText: 'Close',
      loadingText: 'Loading…',
      noOptionsText: 'No options',
      openText: 'Open',
    },
    MuiAlert: {
      closeText: 'Close',
    },
    MuiPagination: {
      'aria-label': 'Pagination navigation',

      getItemAriaLabel: (type, page, selected) => {
        if (type === 'page') {
          return `${selected ? '' : 'Go to '}page ${page}`;
        }
        if (type === 'first') {
          return 'Go to first page';
        }
        if (type === 'last') {
          return 'Go to last page';
        }
        if (type === 'next') {
          return 'Go to next page';
        }
        if (type === 'previous') {
          return 'Go to previous page';
        }
        return undefined;
      },
    },
  },
};

export const getTheMaterialLocale = (locale) => locale;
