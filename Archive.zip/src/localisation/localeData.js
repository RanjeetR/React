import hiData from './hi/staticContent.json';
import staticContent from './en/staticContent';

const locales = {
  hi: {
    locale: 'hi',
    messages: hiData.staticContent,
  },
  en: {
    locale: 'en',
    messages: staticContent,
  },
};

const getLocaleData = (locale) => locales[locale];

export default getLocaleData;
